<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>Help:VisualFileChange.js - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":false,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"a5e34db0-7971-4d4e-a429-2bfc1b3ee387","wgCSPNonce":false,"wgCanonicalNamespace":"Help","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":12,"wgPageName":"Help:VisualFileChange.js","wgTitle":"VisualFileChange.js","wgCurRevisionId":687316779,"wgRevisionId":687316779,"wgArticleId":15859752,"wgIsArticle":true,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["Pages using deprecated enclose attributes","VisualFileChange"],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Help:VisualFileChange.js","wgRelevantArticleId":15859752,"wgIsProbablyEditable":true,"wgRelevantPageIsProbablyEditable":true,
"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":true,"watchlist":true,"tagline":true,"nearby":true},"wgWMESchemaEditAttemptStepOversample":false,"wgWMEPageLength":10000,"wgNoticeProject":"commons","wgVector2022PreviewPages":[],"wgMediaViewerOnClick":true,"wgMediaViewerEnabledByDefault":false,"wgULSCurrentAutonym":"English","wgEditSubmitButtonLabelPublish":true,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiRepoApiUrl":"/w/api.php","wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext","external-id","globe-coordinate","url"],"wgTranslatePageTranslation":"source"
,"wgCentralAuthMobileDomain":false,"wgDiscussionToolsFeaturesEnabled":{"replytool":true,"newtopictool":true,"sourcemodetoolbar":true,"topicsubscription":false,"autotopicsub":false,"visualenhancements":false,"visualenhancements_reply":false,"visualenhancements_pageframe":false},"wgDiscussionToolsFallbackEditMode":"source","wgULSPosition":"personal","wgULSisCompactLinksEnabled":true,"wgWikibaseItemId":"Q23625460"};RLSTATE={"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.gadget.uploadWizardMobile":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","ext.translate":"ready","ext.translate.tag.languages":"ready","ext.pygments":"ready","ext.discussionTools.init.styles":"ready","oojs-ui-core.styles":"ready","oojs-ui.styles.indicators":"ready","mediawiki.widgets.styles":"ready","oojs-ui-core.icons":"ready","skins.vector.styles.legacy":"ready",
"ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.wikimediaBadges":"ready","ext.translate.edit.documentation.styles":"ready","ext.uls.pt":"ready","wikibase.client.init":"ready"};RLPAGEMODULES=["site","mediawiki.page.ready","mediawiki.toc","skins.vector.legacy.js","mmv.head","mmv.bootstrap.autostart","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.centralNotice.geoIP","ext.centralNotice.startUp","ext.translate.pagetranslation.uls","ext.translate.edit.documentation","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.discussionTools.init","ext.uls.compactlinks","ext.uls.interface"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.discussionTools.init.styles%7Cext.pygments%2Ctranslate%2CwikimediaBadges%7Cext.translate.edit.documentation.styles%7Cext.translate.tag.languages%7Cext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cmediawiki.widgets.styles%7Coojs-ui-core.icons%2Cstyles%7Coojs-ui.styles.indicators%7Cskins.vector.styles.legacy%7Cwikibase.client.init&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories%2CuploadWizardMobile&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.40.0-wmf.5"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="max-image-preview:standard"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="viewport" content="width=1000"/>
<meta property="og:title" content="Help:VisualFileChange.js - Wikimedia Commons"/>
<meta property="og:type" content="website"/>
<link rel="preconnect" href="//upload.wikimedia.org"/>
<link rel="alternate" media="only screen and (max-width: 720px)" href="//commons.m.wikimedia.org/wiki/Help:VisualFileChange.js"/>
<link rel="alternate" type="application/x-wiki" title="Edit" href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="https://creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/Help:VisualFileChange.js"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
</head>
<body class="ext-discussiontools-replytool-enabled ext-discussiontools-newtopictool-enabled ext-discussiontools-sourcemodetoolbar-enabled mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-12 ns-subject mw-editable page-Help_VisualFileChange_js rootpage-Help_VisualFileChange_js skin-vector action-view skin-vector-legacy vector-toc-not-collapsed vector-feature-language-in-header-disabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-legacy-toc-disabled vector-feature-visual-enhancement-next-disabled vector-feature-article-tools-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"><!-- CentralNotice --></div>
	<div class="mw-indicators">
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading"><span class="mw-page-title-namespace">Help</span><span class="mw-page-title-separator">:</span><span class="mw-page-title-main">VisualFileChange.js</span></h1>
	<div id="bodyContent" class="vector-body">
		<div id="siteSub" class="noprint">From Wikimedia Commons, the free media repository</div>
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content mw-content-ltr" lang="en" dir="ltr"><div class="mw-pt-translate-header noprint nomobile" dir="ltr" lang="en"><a href="/w/index.php?title=Special:Translate&amp;group=page-Help%3AVisualFileChange.js&amp;action=page&amp;filter=" title="Special:Translate">Translate this page</a></div><div class="mw-parser-output"><div class="mw-pt-languages noprint" lang="en" dir="ltr"><div class="mw-pt-languages-label">Other languages:</div><ul class="mw-pt-languages-list"><li><a href="/wiki/Help:VisualFileChange.js/id" class="mw-pt-progress mw-pt-progress--stub" title="Help:VisualFileChange.js/id (3% translated)" lang="id" dir="ltr">Bahasa Indonesia</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/de" class="mw-pt-progress mw-pt-progress--complete" title="Hilfe:VisualFileChange.js (100% translated)" lang="de" dir="ltr">Deutsch</a></li>
<li><span class="mw-pt-languages-ui mw-pt-languages-selected mw-pt-progress mw-pt-progress--complete" lang="en" dir="ltr">English</span></li>
<li><a href="/wiki/Help:VisualFileChange.js/vi" class="mw-pt-progress mw-pt-progress--stub" title="Trợ giúp:VisualFileChange.js (1% translated)" lang="vi" dir="ltr">Tiếng Việt</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/da" class="mw-pt-progress mw-pt-progress--stub" title="Help:VisualFileChange.js/da (6% translated)" lang="da" dir="ltr">dansk</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/es" class="mw-pt-progress mw-pt-progress--med" title="Ayuda:VisualFileChange.js (47% translated)" lang="es" dir="ltr">español</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/fr" class="mw-pt-progress mw-pt-progress--complete" title="Help:VisualFileChange.js (100% translated)" lang="fr" dir="ltr">français</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/pt-br" class="mw-pt-progress mw-pt-progress--stub" title="Help:VisualFileChange.js/pt-br (3% translated)" lang="pt-BR" dir="ltr">português do Brasil</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/ru" class="mw-pt-progress mw-pt-progress--med" title="Помощь:VisualFileChange.js (44% translated)" lang="ru" dir="ltr">русский</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/uk" class="mw-pt-progress mw-pt-progress--complete" title="Help:VisualFileChange.js (97% translated)" lang="uk" dir="ltr">українська</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/ar" class="mw-pt-progress mw-pt-progress--complete" title="مساعدة:تغيير الملفات المرئي.جس (97% translated)" lang="ar" dir="rtl">العربية</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/sd" class="mw-pt-progress mw-pt-progress--stub" title="مدد:وزيوئل فائل تبديلي.js (1% translated)" lang="sd" dir="rtl">سنڌي</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/bn" class="mw-pt-progress mw-pt-progress--stub" title="সাহায্য:VisualFileChange.js (6% translated)" lang="bn" dir="ltr">বাংলা</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/tcy" class="mw-pt-progress mw-pt-progress--stub" title="ಸಹಾಯೊ:ದೃಶ್ಯೊ ಪೈಲ್‌ತ ಬದಲಾವಣೆ.js (1% translated)" lang="tcy" dir="ltr">ತುಳು</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/zh" class="mw-pt-progress mw-pt-progress--med" title="-{zh:Help; zh-hans:帮助; zh-hant:說明;}-:VisualFileChange.js (56% translated)" lang="zh" dir="ltr">中文</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/ja" class="mw-pt-progress mw-pt-progress--complete" title="ヘルプ:VisualFileChange.js (97% translated)" lang="ja" dir="ltr">日本語</a></li>
<li><a href="/wiki/Help:VisualFileChange.js/ko" class="mw-pt-progress mw-pt-progress--stub" title="Help:VisualFileChange.js (13% translated)" lang="ko" dir="ltr">한국어</a></li></ul></div><table class="plainlinks plainlinks layouttemplate tmbox tmbox-notice" role="presentation"><tbody><tr><td class="mbox-image"><a href="/wiki/File:Question_book-new.svg" class="image"><img alt="Question book-new.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Question_book-new.svg/40px-Question_book-new.svg.png" decoding="async" width="40" height="31" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Question_book-new.svg/60px-Question_book-new.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Question_book-new.svg/80px-Question_book-new.svg.png 2x" data-file-width="512" data-file-height="399"/></a></td><td class="mbox-text">This is the documentation for <b>VisualFileChange</b>, a JavaScript gadget for mass editing. The script itself is located at <a href="/wiki/MediaWiki:Gadget-VisualFileChange.js" title="MediaWiki:Gadget-VisualFileChange.js">MediaWiki:Gadget-VisualFileChange.js</a>.</td></tr></tbody></table> <div style="float:right; clear:right; margin-left:1em; margin-bottom:0.5em; width:248px; border:#99b3ff solid 1px; background-color:transparent;text-align:center;"><abbr title="Have another version in your cache? Go to your browser's menus: There is an option: Clear Recent History and select cache">Current version: 0.10.0.0</abbr></div>
<div id="toc" class="toc" role="navigation" aria-labelledby="mw-toc-heading"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2 id="mw-toc-heading">Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
<ul>
<li class="toclevel-1 tocsection-1"><a href="#What_is_VFC?"><span class="tocnumber">1</span> <span class="toctext">What is VFC?</span></a></li>
<li class="toclevel-1 tocsection-2"><a href="#Documentation"><span class="tocnumber">2</span> <span class="toctext">Documentation</span></a>
<ul>
<li class="toclevel-2 tocsection-3"><a href="#Step_0:_How_to_Install"><span class="tocnumber">2.1</span> <span class="toctext">Step 0: How to Install</span></a></li>
<li class="toclevel-2 tocsection-4"><a href="#Step_1:_Insert_contributor"><span class="tocnumber">2.2</span> <span class="toctext">Step 1: Insert contributor</span></a></li>
<li class="toclevel-2 tocsection-5"><a href="#Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text"><span class="tocnumber">2.3</span> <span class="toctext">Step 2: Select action, insert reason, replace and pattern, tags or free text</span></a></li>
<li class="toclevel-2 tocsection-6"><a href="#Step_3:_Load_as_many_files_as_you_want_to_change"><span class="tocnumber">2.4</span> <span class="toctext">Step 3: Load as many files as you want to change</span></a></li>
<li class="toclevel-2 tocsection-7"><a href="#Step_4:_Select_items_to_perform_the_action_on"><span class="tocnumber">2.5</span> <span class="toctext">Step 4: Select items to perform the action on</span></a>
<ul>
<li class="toclevel-3 tocsection-8"><a href="#Cute_select_–_Filter_loaded_files"><span class="tocnumber">2.5.1</span> <span class="toctext">Cute select – Filter loaded files</span></a></li>
<li class="toclevel-3 tocsection-9"><a href="#Range_selection_–_Multiple_files_between_two_files"><span class="tocnumber">2.5.2</span> <span class="toctext">Range selection – Multiple files between two files</span></a></li>
<li class="toclevel-3 tocsection-10"><a href="#Custom_replace:_Flags"><span class="tocnumber">2.5.3</span> <span class="toctext">Custom replace: Flags</span></a></li>
</ul>
</li>
<li class="toclevel-2 tocsection-11"><a href="#Step_5:_Execute"><span class="tocnumber">2.6</span> <span class="toctext">Step 5: Execute</span></a></li>
<li class="toclevel-2 tocsection-12"><a href="#Custom_settings"><span class="tocnumber">2.7</span> <span class="toctext">Custom settings</span></a></li>
<li class="toclevel-2 tocsection-13"><a href="#Further_information"><span class="tocnumber">2.8</span> <span class="toctext">Further information</span></a></li>
<li class="toclevel-2 tocsection-14"><a href="#Developing_and_finding_and_fixing_Bugs"><span class="tocnumber">2.9</span> <span class="toctext">Developing and finding and fixing Bugs</span></a></li>
</ul>
</li>
</ul>
</div>

<h2 class="ext-discussiontools-init-section"><span id="What_is_VFC.3F"></span><span class="mw-headline" id="What_is_VFC?" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-What_is_VFC?&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-What_is_VFC?"></span>What is VFC?<span data-mw-comment-end="h-What_is_VFC?"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=1" title="Edit section: What is VFC?">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
<div class="thumb tright"><div class="thumbinner" style="width:156px;"><a href="/wiki/File:Perform_batch_task.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/a/a6/Perform_batch_task.png" decoding="async" width="154" height="52" class="thumbimage" data-file-width="154" data-file-height="52"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:Perform_batch_task.png" class="internal" title="Enlarge"></a></div>“Perform batch task” link in the toolbox</div></div></div>
<p>VisualFileChange (a.k.a. AjaxMassDelete), adds a “Perform batch task” link to your toolbox on wiki pages. Clicking this link allows you to apply actions to some or all of one user's uploads, files in a category, or files displayed in a gallery. Actions include the creation of mass-deletion requests, the insertion of tags or free text, and customized text substitutions (<a href="#RegExpr">regular expressions</a> are supported).
</p><p><br/>
</p>
<h2 class="ext-discussiontools-init-section"><span class="mw-headline" id="Documentation" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Documentation&quot;,&quot;replies&quot;:[&quot;h-Step_0:_How_to_Install-Documentation&quot;,&quot;h-Step_1:_Insert_contributor-Documentation&quot;,&quot;h-Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text-Documentation&quot;,&quot;h-Step_3:_Load_as_many_files_as_you_want_to_change-Documentation&quot;,&quot;h-Step_4:_Select_items_to_perform_the_action_on-Documentation&quot;,&quot;h-Step_5:_Execute-Documentation&quot;,&quot;h-Custom_settings-Documentation&quot;,&quot;h-Further_information-Documentation&quot;,&quot;h-Developing_and_finding_and_fixing_Bugs-Documentation&quot;]}"><span data-mw-comment-start="" id="h-Documentation"></span>Documentation<span data-mw-comment-end="h-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=2" title="Edit section: Documentation">edit</a><span class="mw-editsection-bracket">]</span></span></h2>
<p>See also <a href="/wiki/Help:AjaxQuickDelete" class="mw-redirect" title="Help:AjaxQuickDelete">Help:AjaxQuickDelete</a> for the basics of the automatic deletion requests or “tag file &amp; notify uploader”.
</p>
<h3><span class="mw-headline" id="Step_0:_How_to_Install" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_0:_How_to_Install-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Step_0:_How_to_Install-Documentation"></span>Step 0: How to Install<span data-mw-comment-end="h-Step_0:_How_to_Install-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=3" title="Edit section: Step 0: How to Install">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<div class="scriptonly"><span class="plainlinks"><a class="external text" href="https://commons.wikimedia.org/w/index.php?title=Help:VisualFileChange.js&amp;withModule=ext.gadget.VisualFileChange.core"><span class="submit ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-primary ui-button-large" role="button"><span class="ui-button-icon-primary ui-icon ui-icon-play"> </span><span class="ui-button-text">Just try it without installing</span></span></a></span></div>
<div class="noscript">VisualFileChange is a JavaScript tool. You do not have JavaScript enabled.</div>
<p>To install it:
</p>
<ul><li>Manual: In "<a href="/wiki/Special:Preferences#mw-prefsection-gadgets" title="Special:Preferences">Preferences": "gadgets" tab</a>, "Maintenance tools" section: click  "VisualFileChange" and hit "Save" at bottom of page.</li>
<li>Automatic: <span class="plainlinks"><a class="external text" href="https://commons.wikimedia.org/w/index.php?title=Help:VisualFileChange.js&amp;withJS=MediaWiki:ActivateGadget.js&amp;gadgetname=VisualFileChange">click here and follow the instructions</a></span>.</li>
<li>If you do not have the <a href="/wiki/Special:MyLanguage/Commons:Autopatrolled" title="Special:MyLanguage/Commons:Autopatrolled">autopatrolled</a> right: add <code class="mw-highlight mw-highlight-lang-javascript mw-content-ltr" dir="ltr"><span class="nx">mw</span><span class="p">.</span><span class="nx">loader</span><span class="p">.</span><span class="nx">load</span><span class="p">(</span> <span class="s1">'ext.gadget.VisualFileChange'</span> <span class="p">);</span></code> to <a href="/wiki/Special:MyPage/common.js" title="Special:MyPage/common.js">your common.js</a> or &lt;skin>.js</li></ul>
<p>You should now see a <i>Perform batch task</i> link in your toolbox. Clicking it will launch VisualFileChange.
</p><p>To change the <i>Perform batch task</i> text, add
<code class="mw-highlight mw-highlight-lang-javascript mw-content-ltr" dir="ltr"><span class="nb">window</span><span class="p">.</span><span class="nx">vFC_PortletText</span> <span class="o">=</span> <span class="s1">'&lt;your new portlet text>'</span><span class="p">;</span></code> to <a href="/wiki/Special:MyPage/common.js" title="Special:MyPage/common.js">your common.js</a> or &lt;skin>.js
</p>
<div class="thumb tright"><div class="thumbinner" style="width:222px;"><a href="/wiki/File:VisualFileChange_startDialog.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/VisualFileChange_startDialog.png/220px-VisualFileChange_startDialog.png" decoding="async" width="220" height="131" class="thumbimage" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/VisualFileChange_startDialog.png/330px-VisualFileChange_startDialog.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/VisualFileChange_startDialog.png/440px-VisualFileChange_startDialog.png 2x" data-file-width="916" data-file-height="544"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:VisualFileChange_startDialog.png" class="internal" title="Enlarge"></a></div>The start-dialog prompts for the target</div></div></div>
<h3><span class="mw-headline" id="Step_1:_Insert_contributor" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_1:_Insert_contributor-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Step_1:_Insert_contributor-Documentation"></span>Step 1: Insert contributor<span data-mw-comment-end="h-Step_1:_Insert_contributor-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=4" title="Edit section: Step 1: Insert contributor">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>Script prompts for the contributor, a page name, a category, or a search query. Make sure you spell it correctly.
</p>
<h3><span id="Step_2:_Select_action.2C_insert_reason.2C_replace_and_pattern.2C_tags_or_free_text"></span><span class="mw-headline" id="Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text-Documentation"></span>Step 2: Select action, insert reason, replace and pattern, tags or free text<span data-mw-comment-end="h-Step_2:_Select_action,_insert_reason,_replace_and_pattern,_tags_or_free_text-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=5" title="Edit section: Step 2: Select action, insert reason, replace and pattern, tags or free text">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>OTRS-Members: first fill in the ID or URL and then switch to <i>OTRS- remove tags</i>. With <i>OTRS- add</i> you can add any template to the permission section without removing speedy-deletion- and related-tags.
</p><p>Check <i>Clean permission-section?</i> to remove other stuff from the permission section, if it exists.
</p>
<h3><span class="mw-headline" id="Step_3:_Load_as_many_files_as_you_want_to_change" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_3:_Load_as_many_files_as_you_want_to_change-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Step_3:_Load_as_many_files_as_you_want_to_change-Documentation"></span>Step 3: Load as many files as you want to change<span data-mw-comment-end="h-Step_3:_Load_as_many_files_as_you_want_to_change-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=6" title="Edit section: Step 3: Load as many files as you want to change">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>Only files that are selected and in the dialog will be changed. <a href="/wiki/File:VisualFileChange_queryMore.png" title="File:VisualFileChange queryMore.png">To get more files</a>, scroll down or click on "more". However, do not crash your browser loading too many files. Instead, you can continue where you stopped using the "more options" in the start dialog or the <a href="#Step_5:_Execute">automatically created profile</a>.
</p>
<h3><span class="mw-headline" id="Step_4:_Select_items_to_perform_the_action_on" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_4:_Select_items_to_perform_the_action_on-Documentation&quot;,&quot;replies&quot;:[&quot;h-Cute_select_\u2013_Filter_loaded_files-Step_4:_Select_items_to_perform_the_action_on&quot;,&quot;h-Range_selection_\u2013_Multiple_files_between_two_files-Step_4:_Select_items_to_perform_the_action_on&quot;,&quot;h-Custom_replace:_Flags-Step_4:_Select_items_to_perform_the_action_on&quot;]}"><span data-mw-comment-start="" id="h-Step_4:_Select_items_to_perform_the_action_on-Documentation"></span>Step 4: Select items to perform the action on<span data-mw-comment-end="h-Step_4:_Select_items_to_perform_the_action_on-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=7" title="Edit section: Step 4: Select items to perform the action on">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>There are only items listed, originally uploaded by the specified user. If there are deleted images, the numbers are discontinuous. Script will detect a lot of problem- and OTRS-tags and common license-types and show them under each thumbnail. <a href="/wiki/File:MassDeleteOTRS.png" title="File:MassDeleteOTRS.png">Example</a>
</p>
<div class="center"><div class="floatnone"><a href="/wiki/File:VisualFileChange_selectDialog.png" class="image"><img alt="VisualFileChange selectDialog.png" src="https://upload.wikimedia.org/wikipedia/commons/7/73/VisualFileChange_selectDialog.png" decoding="async" width="1010" height="703" data-file-width="1010" data-file-height="703"/></a></div></div>
<div class="thumb tright"><div class="thumbinner" style="width:222px;"><a href="/wiki/File:VisualFileChange_cuteSelect.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/VisualFileChange_cuteSelect.png/220px-VisualFileChange_cuteSelect.png" decoding="async" width="220" height="153" class="thumbimage" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/VisualFileChange_cuteSelect.png/330px-VisualFileChange_cuteSelect.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/VisualFileChange_cuteSelect.png/440px-VisualFileChange_cuteSelect.png 2x" data-file-width="1010" data-file-height="703"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:VisualFileChange_cuteSelect.png" class="internal" title="Enlarge"></a></div>Just want to pick some files with or without a category? Want to select files uploaded between xx and yy because you got OTRS permission for these files? No problem, click on the select link</div></div></div>
<h4><span id="Cute_select_.E2.80.93_Filter_loaded_files"></span><span class="mw-headline" id="Cute_select_–_Filter_loaded_files" data-mw-comment="{&quot;headingLevel&quot;:4,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Cute_select_\u2013_Filter_loaded_files-Step_4:_Select_items_to_perform_the_action_on&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Cute_select_–_Filter_loaded_files-Step_4:_Select_items_to_perform_the_action_on"></span>Cute select – Filter loaded files<span data-mw-comment-end="h-Cute_select_–_Filter_loaded_files-Step_4:_Select_items_to_perform_the_action_on"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=8" title="Edit section: Cute select – Filter loaded files">edit</a><span class="mw-editsection-bracket">]</span></span></h4>
<p>If you do not specify anything, everything will match and all checkboxes in the thumbnail-dialog will get the state of the one in this dialog. This allows you both, selecting and deselecting.
</p>
<div class="thumb tright"><div class="thumbinner" style="width:222px;"><a href="/wiki/File:VisualFileChange_examineRegexp.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/VisualFileChange_examineRegexp.png/220px-VisualFileChange_examineRegexp.png" decoding="async" width="220" height="153" class="thumbimage" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/VisualFileChange_examineRegexp.png/330px-VisualFileChange_examineRegexp.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/8/89/VisualFileChange_examineRegexp.png/440px-VisualFileChange_examineRegexp.png 2x" data-file-width="1010" data-file-height="703"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:VisualFileChange_examineRegexp.png" class="internal" title="Enlarge"></a></div>VisualFileChange supports multiple RegEx-replace and offers methods to preserve certain areas. In addition, you can preview the changes before they are made.</div></div></div>
<dl><dt>RegExpr <span id="RegExpr"></span> <b>/R/</b></dt></dl>
<p>A RegExpr also known as regular expression or regex is a pattern used to match more than one "string" (e.g. the image text or a title). They can be really helpful anywhere, so, if you are unexperienced don't be lazy and learn them; the earlier, the better.
</p><p>In the cute selection dialog, insert the RegExpr without flags <small>(they are currently not supported)</small> (<code>Test.*</code>); however when performing a custom replace, insert the RegExpr with flags (<code>/\{\{FlickrView.*\|\d{4}\}\}/ig</code>). Don't forget to escape "special characters".
</p><p>Please test your RegExpr before using and use the opportunity to examine the changes the current set of replacement rules would cause to avoid undesired replacements. You can use <a rel="nofollow" class="external free" href="https://regex101.com/">https://regex101.com/</a> (or similar tools) to test your RegExpr.
</p><p>When using regular expressions, VFC follows the same convention as Perl, PHP, and others that in the replacement string, <code>$0</code> matches the whole matched string, <code><code>/[|]\s*[Ss]ource\s*=\s*([^|}]*) on MyCoolWebsite/</code></code> matches the first parenthesized expression, <code><code>| Source = {{MyCoolWebsite|$1}}</code></code> the second parenthesized expression, etc. So, for example, the regular expression <code>/[|]\s*[Ss]ource\s*=\s*([^|}]*) on MyCoolWebsite/</code> with a replacement string <code>| Source = {{MyCoolWebsite|$1}}</code> would turn <code>|source=FOO.BAR on MyCoolWebsite&lt;/nowiki></code> into <code>| Source = {{MyCoolWebsite|FOO.BAR}}</code>.
</p><p>Reference/ Examples: <a rel="nofollow" class="external text" href="http://de.selfhtml.org/javascript/objekte/regexp.htm">de</a>, <a rel="nofollow" class="external text" href="http://www.w3schools.com/jsref/jsref_obj_regexp.asp">en</a>, <a rel="nofollow" class="external text" href="http://www.javascriptkit.com/jsref/regexp.shtml">en</a>
</p>
<h4><span id="Range_selection_.E2.80.93_Multiple_files_between_two_files"></span><span class="mw-headline" id="Range_selection_–_Multiple_files_between_two_files" data-mw-comment="{&quot;headingLevel&quot;:4,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Range_selection_\u2013_Multiple_files_between_two_files-Step_4:_Select_items_to_perform_the_action_on&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Range_selection_–_Multiple_files_between_two_files-Step_4:_Select_items_to_perform_the_action_on"></span>Range selection – Multiple files between two files<span data-mw-comment-end="h-Range_selection_–_Multiple_files_between_two_files-Step_4:_Select_items_to_perform_the_action_on"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=9" title="Edit section: Range selection – Multiple files between two files">edit</a><span class="mw-editsection-bracket">]</span></span></h4>
<p>Select <i>file A</i>, hold down <kbd class="keyboard-key nowrap" style="border:1px solid #aaa;-moz-border-radius:.2em;-webkit-border-radius:.2em;border-radius:.2em;-moz-box-shadow:.1em .1em .2em rgba(0,0,0,.1);-webkit-box-shadow:.1em .1em .2em rgba(0,0,0,.1);box-shadow:.1em .1em .2em rgba(0,0,0,.1);background:#f9f9f9;background-image:-moz-linear-gradient(top,#eee,#f9f9f9,#eee);background-image:-o-linear-gradient(top,#eee,#f9f9f9,#eee);background-image:-webkit-linear-gradient(top,#eee,#f9f9f9,#eee);background-image:linear-gradient(to bottom,#eee,#f9f9f9,#eee);padding:.1em .3em;font-family:inherit;font-size:.85em"><span class="Unicode">⇧</span> Shift</kbd> while selecting <i>file B</i>. All files between the two files now get the state of <i>file B</i>.
</p>
<h4><span class="mw-headline" id="Custom_replace:_Flags" data-mw-comment="{&quot;headingLevel&quot;:4,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Custom_replace:_Flags-Step_4:_Select_items_to_perform_the_action_on&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Custom_replace:_Flags-Step_4:_Select_items_to_perform_the_action_on"></span>Custom replace: Flags<span data-mw-comment-end="h-Custom_replace:_Flags-Step_4:_Select_items_to_perform_the_action_on"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=10" title="Edit section: Custom replace: Flags">edit</a><span class="mw-editsection-bracket">]</span></span></h4>
<ul><li>If <code>/R/</code> is set, the pattern is treated as a regular expression. If the background behind the button is red, it is very likely that you forgot to tick this button. If the background behind the pattern field is red, you ticked this button but the pattern is not a valid regular expression.</li>
<li>If <code>%V%</code> is set, VisualFileChange looks for variables (e.g. File metadata like <code>%GPSLatitude%</code> or the file name <code>%PAGENAME%</code>) in "Text to insert instead". This option is on-by-default. <a href="/wiki/Help:VisualFileChange.js/samples#Inserting_variables" title="Help:VisualFileChange.js/samples">Examples</a>.</li></ul>
<h3><span class="mw-headline" id="Step_5:_Execute" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Step_5:_Execute-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Step_5:_Execute-Documentation"></span>Step 5: Execute<span data-mw-comment-end="h-Step_5:_Execute-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=11" title="Edit section: Step 5: Execute">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>Script will show you what it is currently doing. Finally it prompts you where to go. Before executing, the script saves your input into an auto-profile. This allows you to continue at the last loaded files. If you re-launch VisualFileChange and insert the same target, a big yellow box will appear. Just click the link for convenient continuing.
</p>
<div class="thumb tright"><div class="thumbinner" style="width:222px;"><a href="/wiki/File:VisualFileChange_advancedConfig.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/VisualFileChange_advancedConfig.png/220px-VisualFileChange_advancedConfig.png" decoding="async" width="220" height="153" class="thumbimage" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/VisualFileChange_advancedConfig.png/330px-VisualFileChange_advancedConfig.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/VisualFileChange_advancedConfig.png/440px-VisualFileChange_advancedConfig.png 2x" data-file-width="1010" data-file-height="703"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:VisualFileChange_advancedConfig.png" class="internal" title="Enlarge"></a></div>The advanced configuration. Here you can play around with the defaults. Do not forget to permanently save them.</div></div></div>
<h3><span class="mw-headline" id="Custom_settings" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Custom_settings-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Custom_settings-Documentation"></span>Custom settings<span data-mw-comment-end="h-Custom_settings-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=12" title="Edit section: Custom settings">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<p>VisualFileChange allows you to customize lots of features. It is not recommended to drastically increase the numbers of files to be loaded when scrolling down but it can be helpful in some cases.
</p><p>If you send too many simultaneous requests to the API, errors may rise. Users who are not <abbr title="IPs in wiki-jargon">logged in</abbr> should only send one request at one time. In case of errors, set "ask for confirmation after ... edits" to less than 8 and wait a while when the dialog prompts you whether to continue. We regret this limitation but cannot change it because it is on the server side. There are also much more edit restrictions for users who are not logged in.
</p>
<h3><span class="mw-headline" id="Further_information" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Further_information-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Further_information-Documentation"></span>Further information<span data-mw-comment-end="h-Further_information-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=13" title="Edit section: Further information">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<ul><li><a href="/wiki/Help:VisualFileChange.js/samples" title="Help:VisualFileChange.js/samples">Use cases and examples</a></li>
<li>View more <a href="/wiki/Category:Screenshots_of_VisualFileChange" title="Category:Screenshots of VisualFileChange">screenshots of VisualFileChange</a></li></ul>
<h3><span class="mw-headline" id="Developing_and_finding_and_fixing_Bugs" data-mw-comment="{&quot;headingLevel&quot;:3,&quot;name&quot;:&quot;h-&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Developing_and_finding_and_fixing_Bugs-Documentation&quot;,&quot;replies&quot;:[]}"><span data-mw-comment-start="" id="h-Developing_and_finding_and_fixing_Bugs-Documentation"></span>Developing and finding and fixing Bugs<span data-mw-comment-end="h-Developing_and_finding_and_fixing_Bugs-Documentation"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit&amp;section=14" title="Edit section: Developing and finding and fixing Bugs">edit</a><span class="mw-editsection-bracket">]</span></span></h3>
<ul><li>Please report bugs at <a href="/wiki/MediaWiki_talk:Gadget-VisualFileChange.js" title="MediaWiki talk:Gadget-VisualFileChange.js">MediaWiki talk:Gadget-VisualFileChange.js</a></li>
<li><a href="/wiki/File:AjaxMassDelete_FlowChart.png" title="File:AjaxMassDelete FlowChart.png">flow chart</a> (outdated)</li></ul>
<!-- 
NewPP limit report
Parsed by mw2338
Cached time: 20221005203945
Cache expiry: 1814400
Reduced expiry: false
Complications: [show‐toc]
DiscussionTools time usage: 0.009 seconds
CPU time usage: 0.107 seconds
Real time usage: 0.207 seconds
Preprocessor visited node count: 403/1000000
Post‐expand include size: 5789/2097152 bytes
Template argument size: 863/2097152 bytes
Highest expansion depth: 13/100
Expensive parser function count: 2/500
Unstrip recursion depth: 0/20
Unstrip post‐expand size: 4305/5000000 bytes
Lua time usage: 0.009/10.000 seconds
Lua memory usage: 873586/52428800 bytes
Number of Wikibase entities loaded: 0/400
-->
<!--
Transclusion expansion time report (%,ms,calls,template)
100.00%   65.697      1 -total
 39.97%   26.261      1 Template:Tmbox
 16.63%   10.923      1 Template:JS-Test
 14.44%    9.485      2 Template:LangSwitch
 13.92%    9.148      1 Template:Keypress
 12.57%    8.260      1 MediaWiki:VisualFileChange.js/versionBox
 10.95%    7.194      1 Template:Anchor
  8.47%    5.567      1 Template:Key_press/core
  6.81%    4.477      1 Template:Clickable_button
  6.00%    3.944      1 MediaWiki:VisualFileChange.js/version
-->

<!-- Saved in parser cache with key commonswiki:pcache:idhash:15859752-0!canonical and timestamp 20221005203945 and revision id 687316779.
 -->
</div><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/w/index.php?title=Help:VisualFileChange.js&amp;oldid=687316779">https://commons.wikimedia.org/w/index.php?title=Help:VisualFileChange.js&amp;oldid=687316779</a>"</div></div>
		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-normal-catlinks" class="mw-normal-catlinks"><a href="/wiki/Special:Categories" title="Special:Categories">Category</a>: <ul><li><a href="/wiki/Category:VisualFileChange" title="Category:VisualFileChange">VisualFileChange</a></li></ul></div><div id="mw-hidden-catlinks" class="mw-hidden-catlinks mw-hidden-cats-user-shown">Hidden category: <ul><li><a href="/wiki/Category:Pages_using_deprecated_enclose_attributes" title="Category:Pages using deprecated enclose attributes">Pages using deprecated enclose attributes</a></li></ul></div></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-uls" class="mw-list-item active"><a class="uls-trigger" href="#"><span>English</span></a></li><li id="pt-anonuserpage" class="mw-list-item"><span title="The user page for the IP address you are editing as">Not logged in</span></li><li id="pt-anontalk" class="mw-list-item"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n"><span>Talk</span></a></li><li id="pt-anoncontribs" class="mw-list-item"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y"><span>Contributions</span></a></li><li id="pt-createaccount" class="mw-list-item"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Help%3AVisualFileChange.js" title="You are encouraged to create an account and log in; however, it is not mandatory"><span>Create account</span></a></li><li id="pt-login" class="mw-list-item"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Help%3AVisualFileChange.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-help" class="selected mw-list-item"><a href="/wiki/Help:VisualFileChange.js" title="View the help page [c]" accesskey="c"><span>Help page</span></a></li><li id="ca-talk" class="mw-list-item"><a href="/wiki/Help_talk:VisualFileChange.js" rel="discussion" title="Discussion about the content page [t]" accesskey="t"><span>Discussion</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-view" class="selected vector-tab-noicon mw-list-item"><a href="/wiki/Help:VisualFileChange.js"><span>View</span></a></li><li id="ca-edit" class="vector-tab-noicon mw-list-item"><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=edit" title="Edit this page [e]" accesskey="e"><span>Edit</span></a></li><li id="ca-history" class="vector-tab-noicon mw-list-item"><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=history" title="Past revisions of this page [h]" accesskey="h"><span>History</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/w/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Wikimedia Commons" aria-label="Search Wikimedia Commons" autocapitalize="sentences" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:MediaSearch">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/wiki/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-navigation" class="vector-menu mw-portlet mw-portlet-navigation vector-menu-portal portal" aria-labelledby="p-navigation-label" role="navigation"  >
	<h3
		id="p-navigation-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Navigate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-mainpage-description" class="mw-list-item"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z"><span>Main page</span></a></li><li id="n-welcome" class="mw-list-item"><a href="/wiki/Commons:Welcome"><span>Welcome</span></a></li><li id="n-portal" class="mw-list-item"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things"><span>Community portal</span></a></li><li id="n-village-pump" class="mw-list-item"><a href="/wiki/Commons:Village_pump"><span>Village pump</span></a></li><li id="n-help" class="mw-list-item"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out"><span>Help center</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-participate" class="vector-menu mw-portlet mw-portlet-participate vector-menu-portal portal" aria-labelledby="p-participate-label" role="navigation"  >
	<h3
		id="p-participate-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Participate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-uploadbtn" class="mw-list-item"><a href="/wiki/Special:UploadWizard"><span>Upload file</span></a></li><li id="n-recentchanges" class="mw-list-item"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r"><span>Recent changes</span></a></li><li id="n-latestfiles" class="mw-list-item"><a href="/wiki/Special:NewFiles"><span>Latest files</span></a></li><li id="n-randomimage" class="mw-list-item"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x"><span>Random file</span></a></li><li id="n-contact" class="mw-list-item"><a href="/wiki/Commons:Contact_us"><span>Contact us</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere" class="mw-list-item"><a href="/wiki/Special:WhatLinksHere/Help:VisualFileChange.js" title="A list of all wiki pages that link here [j]" accesskey="j"><span>What links here</span></a></li><li id="t-recentchangeslinked" class="mw-list-item"><a href="/wiki/Special:RecentChangesLinked/Help:VisualFileChange.js" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k"><span>Related changes</span></a></li><li id="t-specialpages" class="mw-list-item"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-permalink" class="mw-list-item"><a href="/w/index.php?title=Help:VisualFileChange.js&amp;oldid=687316779" title="Permanent link to this revision of this page"><span>Permanent link</span></a></li><li id="t-info" class="mw-list-item"><a href="/w/index.php?title=Help:VisualFileChange.js&amp;action=info" title="More information about this page"><span>Page information</span></a></li><li id="t-wikibase" class="mw-list-item"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q23625460" title="Link to connected data repository item [g]" accesskey="g"><span>Wikidata item</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-coll-print_export" class="vector-menu mw-portlet mw-portlet-coll-print_export vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" role="navigation"  >
	<h3
		id="p-coll-print_export-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Print/export</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="coll-create_a_book" class="mw-list-item"><a href="/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=Help%3AVisualFileChange.js"><span>Create a book</span></a></li><li id="coll-download-as-rl" class="mw-list-item"><a href="/w/index.php?title=Special:DownloadAsPdf&amp;page=Help%3AVisualFileChange.js&amp;action=show-download-screen"><span>Download as PDF</span></a></li><li id="t-print" class="mw-list-item"><a href="/w/index.php?title=Help:VisualFileChange.js&amp;printable=yes" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-lang" class="vector-menu mw-portlet mw-portlet-lang vector-menu-portal portal" aria-labelledby="p-lang-label" role="navigation"  >
	<h3
		id="p-lang-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">In Wikipedia</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		<div class="after-portlet after-portlet-lang"><span class="wb-langlinks-add wb-langlinks-link"><a href="https://www.wikidata.org/wiki/Special:EntityPage/Q23625460#sitelinks-wikipedia" title="Add interlanguage links" class="wbc-editpage">Add links</a></span></div>
	</div>
</nav>

</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
	<li id="footer-info-lastmod"> This page was last edited on 8 September 2022, at 04:55.</li>
	<li id="footer-info-copyright">Files are available under licenses specified on their description page. All structured data from the file namespace is available under the <a href="https://creativecommons.org/publicdomain/zero/1.0/" title="Definition of the Creative Commons CC0 License">Creative Commons CC0 License</a>; all unstructured text is available under the <a href="https://creativecommons.org/licenses/by-sa/3.0/" title="Definition of the Creative Commons Attribution/Share-Alike License">Creative Commons Attribution-ShareAlike License</a>;
additional terms may apply.
By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use" title="Wikimedia Foundation Terms of Use">Terms of Use</a> and the <a href="//foundation.wikimedia.org/wiki/Privacy_policy" title="Wikimedia Foundation Privacy Policy">Privacy Policy</a>.</li>
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/wiki/Commons:Welcome">About Wikimedia Commons</a></li>
	<li id="footer-places-disclaimers"><a href="/wiki/Commons:General_disclaimer">Disclaimers</a></li>
	<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=Help:VisualFileChange.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	<li id="footer-places-developers"><a href="https://developer.wikimedia.org">Developers</a></li>
	<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
	<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/footer/wikimedia-button.png" srcset="/static/images/footer/wikimedia-button-1.5x.png 1.5x, /static/images/footer/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/footer/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/footer/poweredby_mediawiki_132x47.png 1.5x, /static/images/footer/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"discussiontools":{"limitreport-timeusage":"0.009"},"limitreport":{"cputime":"0.107","walltime":"0.207","ppvisitednodes":{"value":403,"limit":1000000},"postexpandincludesize":{"value":5789,"limit":2097152},"templateargumentsize":{"value":863,"limit":2097152},"expansiondepth":{"value":13,"limit":100},"expensivefunctioncount":{"value":2,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":4305,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%   65.697      1 -total"," 39.97%   26.261      1 Template:Tmbox"," 16.63%   10.923      1 Template:JS-Test"," 14.44%    9.485      2 Template:LangSwitch"," 13.92%    9.148      1 Template:Keypress"," 12.57%    8.260      1 MediaWiki:VisualFileChange.js/versionBox"," 10.95%    7.194      1 Template:Anchor","  8.47%    5.567      1 Template:Key_press/core","  6.81%    4.477      1 Template:Clickable_button","  6.00%    3.944      1 MediaWiki:VisualFileChange.js/version"]},"scribunto":{"limitreport-timeusage":{"value":"0.009","limit":"10.000"},"limitreport-memusage":{"value":873586,"limit":52428800}},"cachereport":{"origin":"mw2338","timestamp":"20221005203945","ttl":1814400,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":88,"wgHostname":"mw2301"});});</script>
</body>
</html>
<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>MediaWiki talk:Gadget-HotCat.js - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":true,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"122d3feb-2f74-47e7-856c-c4dd355df2a3","wgCSPNonce":false,"wgCanonicalNamespace":"MediaWiki_talk","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":9,"wgPageName":"MediaWiki_talk:Gadget-HotCat.js","wgTitle":"Gadget-HotCat.js","wgCurRevisionId":685194842,"wgRevisionId":685194842,"wgArticleId":3190584,"wgIsArticle":true,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["Pages using deprecated source tags","Gadget scripts"],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"MediaWiki_talk:Gadget-HotCat.js","wgRelevantArticleId":3190584,"wgIsProbablyEditable":true,"wgRelevantPageIsProbablyEditable":
true,"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":true,"watchlist":true,"tagline":true,"nearby":true},"wgWMESchemaEditAttemptStepOversample":false,"wgWMEPageLength":10000,"wgNoticeProject":"commons","wgVector2022PreviewPages":[],"wgMediaViewerOnClick":true,"wgMediaViewerEnabledByDefault":false,"wgULSCurrentAutonym":"English","wgEditSubmitButtonLabelPublish":true,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiRepoApiUrl":"/w/api.php","wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext","external-id","globe-coordinate","url"],"wgCentralAuthMobileDomain":
false,"wgDiscussionToolsFeaturesEnabled":{"replytool":true,"newtopictool":true,"sourcemodetoolbar":true,"topicsubscription":false,"autotopicsub":false,"visualenhancements":false,"visualenhancements_reply":false,"visualenhancements_pageframe":false},"wgDiscussionToolsFallbackEditMode":"source","wgULSPosition":"personal","wgULSisCompactLinksEnabled":true};RLSTATE={"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.gadget.uploadWizardMobile":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","mediawiki.special":"ready","ext.inputBox.styles":"ready","mediawiki.ui.input":"ready","mediawiki.ui.checkbox":"ready","ext.pygments":"ready","ext.discussionTools.init.styles":"ready","oojs-ui-core.styles":"ready","oojs-ui.styles.indicators":"ready","mediawiki.widgets.styles":"ready","oojs-ui-core.icons":"ready","skins.vector.styles.legacy":"ready","jquery.makeCollapsible.styles":"ready"
,"mediawiki.ui.button":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.wikimediaBadges":"ready","ext.uls.pt":"ready"};RLPAGEMODULES=["site","mediawiki.page.ready","jquery.makeCollapsible","mediawiki.toc","skins.vector.legacy.js","mmv.head","mmv.bootstrap.autostart","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.centralNotice.geoIP","ext.centralNotice.startUp","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete","ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.discussionTools.init","ext.uls.compactlinks","ext.uls.interface"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.discussionTools.init.styles%7Cext.inputBox.styles%7Cext.pygments%2CwikimediaBadges%7Cext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cjquery.makeCollapsible.styles%7Cmediawiki.special%7Cmediawiki.ui.button%2Ccheckbox%2Cinput%7Cmediawiki.widgets.styles%7Coojs-ui-core.icons%2Cstyles%7Coojs-ui.styles.indicators%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories%2CuploadWizardMobile&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.40.0-wmf.5"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="max-image-preview:standard"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="viewport" content="width=1000"/>
<meta property="og:title" content="MediaWiki talk:Gadget-HotCat.js - Wikimedia Commons"/>
<meta property="og:type" content="website"/>
<link rel="preconnect" href="//upload.wikimedia.org"/>
<link rel="alternate" media="only screen and (max-width: 720px)" href="//commons.m.wikimedia.org/wiki/MediaWiki_talk:Gadget-HotCat.js"/>
<link rel="alternate" type="application/x-wiki" title="Edit" href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="https://creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/MediaWiki_talk:Gadget-HotCat.js"/>
<link rel="dns-prefetch" href="//meta.wikimedia.org" />
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
</head>
<body class="ext-discussiontools-replytool-enabled ext-discussiontools-newtopictool-enabled ext-discussiontools-sourcemodetoolbar-enabled mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-9 ns-talk mw-editable page-MediaWiki_talk_Gadget-HotCat_js rootpage-MediaWiki_talk_Gadget-HotCat_js skin-vector action-view skin-vector-legacy vector-toc-not-collapsed vector-feature-language-in-header-disabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-legacy-toc-disabled vector-feature-visual-enhancement-next-disabled vector-feature-article-tools-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"><!-- CentralNotice --></div>
	<div class="mw-indicators">
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading"><span class="mw-page-title-namespace">MediaWiki talk</span><span class="mw-page-title-separator">:</span><span class="mw-page-title-main">Gadget-HotCat.js</span></h1>
	<div id="bodyContent" class="vector-body">
		<div id="siteSub" class="noprint">From Wikimedia Commons, the free media repository</div>
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content mw-content-ltr" lang="en" dir="ltr"><div class="mw-parser-output"><table class="plainlinks plainlinks layouttemplate tmbox tmbox-notice" role="presentation" style="margin:1px 10%"><tbody><tr><td class="mbox-image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/40px-Information_icon4.svg.png" decoding="async" width="40" height="40" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/60px-Information_icon4.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/Information_icon4.svg/80px-Information_icon4.svg.png 2x" data-file-width="620" data-file-height="620"/></td><td class="mbox-text">This script, <i><b><bdi>HotCat</bdi></b></i>, is a JavaScript <a href="/wiki/Commons:Gadgets" title="Commons:Gadgets">gadget</a> which can be enabled or disabled in <a href="/wiki/Special:Preferences#mw-prefsection-gadgets-Gadget-HotCat" title="Special:Preferences">your Preferences</a>. The documentation page is located at <b><a href="/wiki/Help:Gadget-HotCat" title="Help:Gadget-HotCat">Help:Gadget-HotCat</a></b>.</td></tr></tbody></table><table class="plainlinks plainlinks layouttemplate tmbox tmbox-notice" role="presentation" style="margin:1px 10%"><tbody><tr><td class="mbox-image"><a href="/wiki/File:Farm-Fresh_tag_blue_edit.png" class="image"><img alt="Farm-Fresh tag blue edit.png" src="https://upload.wikimedia.org/wikipedia/commons/d/d0/Farm-Fresh_tag_blue_edit.png" decoding="async" width="34" height="34" data-file-width="32" data-file-height="32"/></a></td><td class="mbox-text"><div style="margin-top:2px; padding:.4em 1em .5em; border:1px solid #d4cfa4; background:#fff9db;">Gadget descriptions: <div class="lang-links-cheap"><style data-mw-deduplicate="TemplateStyles:r577973462">.mw-parser-output .lang-links-cheap .mw-prefixindex-body{columns:1}.mw-parser-output .lang-links-cheap ul{margin:0}.mw-parser-output .lang-links-cheap li,.mw-parser-output .lang-links-cheap li *{display:inline}.mw-parser-output .lang-links-cheap li::after{content:" ∙"}.mw-parser-output .lang-links-cheap li:last-child::after{content:none}</style><div class="mw-prefixindex-body"><ul class="mw-prefixindex-list"><li><a href="/wiki/MediaWiki:Gadget-HotCat/ar" title="MediaWiki:Gadget-HotCat/ar">ar</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/bg" title="MediaWiki:Gadget-HotCat/bg">bg</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/bn" title="MediaWiki:Gadget-HotCat/bn">bn</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/ca" title="MediaWiki:Gadget-HotCat/ca">ca</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/cs" title="MediaWiki:Gadget-HotCat/cs">cs</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/de" title="MediaWiki:Gadget-HotCat/de">de</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/es" title="MediaWiki:Gadget-HotCat/es">es</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/eu" title="MediaWiki:Gadget-HotCat/eu">eu</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/fa" title="MediaWiki:Gadget-HotCat/fa">fa</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/fi" title="MediaWiki:Gadget-HotCat/fi">fi</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/fr" title="MediaWiki:Gadget-HotCat/fr">fr</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/gl" title="MediaWiki:Gadget-HotCat/gl">gl</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/gu" title="MediaWiki:Gadget-HotCat/gu">gu</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/hi" title="MediaWiki:Gadget-HotCat/hi">hi</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/hr" title="MediaWiki:Gadget-HotCat/hr">hr</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/hu" title="MediaWiki:Gadget-HotCat/hu">hu</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/it" title="MediaWiki:Gadget-HotCat/it">it</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/ja" title="MediaWiki:Gadget-HotCat/ja">ja</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/kk" title="MediaWiki:Gadget-HotCat/kk">kk</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/kk-cyrl" title="MediaWiki:Gadget-HotCat/kk-cyrl">kk-cyrl</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/ko" title="MediaWiki:Gadget-HotCat/ko">ko</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/lang" title="MediaWiki:Gadget-HotCat/lang">lang</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/mk" title="MediaWiki:Gadget-HotCat/mk">mk</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/ml" title="MediaWiki:Gadget-HotCat/ml">ml</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/my" title="MediaWiki:Gadget-HotCat/my">my</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/nl" title="MediaWiki:Gadget-HotCat/nl">nl</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/no" title="MediaWiki:Gadget-HotCat/no">no</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/pl" title="MediaWiki:Gadget-HotCat/pl">pl</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/pt" title="MediaWiki:Gadget-HotCat/pt">pt</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/ru" title="MediaWiki:Gadget-HotCat/ru">ru</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/sl" title="MediaWiki:Gadget-HotCat/sl">sl</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/sv" title="MediaWiki:Gadget-HotCat/sv">sv</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/uk" title="MediaWiki:Gadget-HotCat/uk">uk</a></li>
<li><a href="/wiki/MediaWiki:Gadget-HotCat/zh-hans" title="MediaWiki:Gadget-HotCat/zh-hans">zh-hans</a></li>
</ul></div></div> <small></small><br/><span id="mw-prefsection-gadgets-Gadget-HotCat" lang="en" dir="ltr"><bdi><i>HotCat</i></bdi>: <sup><abbr title="default gadget – enabled by default">d</abbr></sup> Easily add / remove / change a category on a page, with name suggestions.</span> <small>[<a href="/wiki/Help:Gadget-HotCat" title="Help:Gadget-HotCat"><bdi>documentation</bdi></a> / <a href="/wiki/File:HotCat.png" title="File:HotCat.png"><bdi>example</bdi></a> / <a class="mw-selflink selflink"><bdi>talk</bdi></a>]</small> 
</div></td></tr></tbody></table><table class="plainlinks plainlinks layouttemplate tmbox tmbox-notice" role="presentation"><tbody><tr><td class="mbox-image"><div style="font-family:monospace;font-weight:bold;font-size:big;height:34px;width:34px;padding-top:15px;"><abbr title="Internationalization">i18n</abbr></div></td><td class="mbox-text"><div style="margin-top:2px; padding:.4em 1em .5em; border:1px solid #d4cfa4; background:#fff9db;">Gadget translations: 
<p><span style="font-size:x-small;line-height:140%" class="plainlinks noprint"><a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/als">Alemannisch</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ar">العربية</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/arc">ܐܪܡܝܐ</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/az">Azərbaycanca</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/be">Беларуская</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/be-tarask">Беларуская (тарашкевіца)‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/bjn">Bahasa Banjar</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/bn">বাংলা</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ca">Català</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ce">Нохчийн</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/cs">Čeština</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/da">Dansk</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/de">Deutsch</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/de-formal">Deutsch (Sie-Form)‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/dsb">Dolnoserbski</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/el">Ελληνικά</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/en">English</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/eo">Esperanto</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/es">Español</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/et">Eesti</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fa">فارسی</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fi">Suomi</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/fr">Français</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/frr">Nordfriisk</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/gl">Galego</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/he">עברית</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hr">Hrvatski</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hsb">Hornjoserbsce</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hu">Magyar</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/hy">Հայերեն</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/id">Bahasa Indonesia</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ilo">Ilokano</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/it">Italiano</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ja">日本語</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ka">ქართული</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/kk">Қазақша</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/kk-cyrl">Қазақша (кирил)‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ko">한국어</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ku">Kurdî</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/lt">Lietuvių</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/lv">Latviešu</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/min">Baso Minangkabau</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ml">മലയാളം</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ms">Bahasa Melayu</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/nl">Nederlands</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/nn">Norsk nynorsk</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/no">Norsk bokmål</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pl">Polski</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pt">Português</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/pt-br">Português do Brasil</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ro">Română</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ru">Русский</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/si">සිංහල</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sk">Slovenčina</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sl">Slovenščina</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sq">Shqip</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sr">Српски / srpski</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/sv">Svenska</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/szl">Ślůnski</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/te">తెలుగు</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/tr">Türkçe</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/tt">Татарча/tatarça</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/uk">Українська</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/ur">اردو</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh">中文</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-cn">中文（中国大陆）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hans">中文（简体）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hant">中文（繁體）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-hk">中文（香港）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-mo">中文（澳門）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-my">中文（马来西亚）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-sg">中文（新加坡）‎</a> | <a class="external text" href="https://commons.wikimedia.org/wiki/MediaWiki:Gadget-HotCat.js/zh-tw">中文（台灣）‎</a> | <small class="plainlinks"><a class="external text" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadget-HotCat.js/lang/lang&amp;action=edit">+/−</a></small>
</span> <bdi></bdi>
</p>
</div></td></tr></tbody></table>
<p><br/>

</p>
<table id="archivebox" role="presentation" class="tmbox tmbox-notice mbox-small" style="padding-top:4px; text-align: center;">
<tbody><tr><th><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/40px-Replacement_filing_cabinet.svg.png" decoding="async" width="40" height="40" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/60px-Replacement_filing_cabinet.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Replacement_filing_cabinet.svg/80px-Replacement_filing_cabinet.svg.png 2x" data-file-width="200" data-file-height="200"/><br/><a href="/wiki/Special:MyLanguage/Commons:Talk_page_guidelines#Archiving" title="Special:MyLanguage/Commons:Talk page guidelines">
</a><p><a href="/wiki/Special:MyLanguage/Commons:Talk_page_guidelines#Archiving" title="Special:MyLanguage/Commons:Talk page guidelines"><bdi lang="en">Archives</bdi></a>
</p>
</th></tr>
<tr><td style="text-align:left;">
<ul><li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive01" title="MediaWiki talk:Gadget-HotCat.js/Archive01">Archive 1</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive02" title="MediaWiki talk:Gadget-HotCat.js/Archive02">Archive 2</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive03" title="MediaWiki talk:Gadget-HotCat.js/Archive03">Archive 3</a></li>
<li><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive04" title="MediaWiki talk:Gadget-HotCat.js/Archive04">Archive 4</a></li></ul>
</td></tr><tr><td><div class="mw-inputbox-centered" style=""><form name="searchbox" class="searchbox" action="/wiki/Special:Search"><input class="mw-searchInput searchboxInput mw-ui-input mw-ui-input-inline" name="search" placeholder="" size="22" dir="ltr"/><input type="hidden" value="MediaWiki talk:Gadget-HotCat.js/" name="prefix"/> <input type="submit" name="fulltext" class="mw-ui-button" value="Search"/><input type="hidden" value="Search" name="fulltext"/></form></div>
</td></tr><tr><td>Threads older than 180 days days may be archived.</td></tr>
</tbody></table>
<div id="toc" class="toc" role="navigation" aria-labelledby="mw-toc-heading"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2 id="mw-toc-heading">Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
<ul>
<li class="toclevel-1 tocsection-1"><a href="#Cursor_jumping_to_the_end"><span class="tocnumber">1</span> <span class="toctext">Cursor jumping to the end</span></a></li>
<li class="toclevel-1 tocsection-2"><a href="#API_deprecation_notice_about_rvslots"><span class="tocnumber">2</span> <span class="toctext">API deprecation notice about rvslots</span></a></li>
<li class="toclevel-1 tocsection-3"><a href="#Dropped-categories_bug"><span class="tocnumber">3</span> <span class="toctext">Dropped-categories bug</span></a></li>
<li class="toclevel-1 tocsection-4"><a href="#Global_Localization_for_Thai"><span class="tocnumber">4</span> <span class="toctext">Global Localization for Thai</span></a></li>
<li class="toclevel-1 tocsection-5"><a href="#A_hint_to_a_user_attempting_to_remove_a_sort_key"><span class="tocnumber">5</span> <span class="toctext">A hint to a user attempting to remove a sort key</span></a></li>
<li class="toclevel-1 tocsection-6"><a href="#Mobile_compatibility"><span class="tocnumber">6</span> <span class="toctext">Mobile compatibility</span></a></li>
</ul>
</div>

<p><br/>
</p>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-Nikki-2021-07-27T18:18:00.000Z--><!--__DTSUBSCRIBELINK__h-Nikki-2021-07-27T18:18:00.000Z--><span class="mw-headline" id="Cursor_jumping_to_the_end" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Cursor_jumping_to_the_end-2021-07-27T18:18:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Nikki-2021-07-27T18:18:00.000Z-Cursor_jumping_to_the_end&quot;]}"><span data-mw-comment-start="" id="h-Cursor_jumping_to_the_end-2021-07-27T18:18:00.000Z"></span>Cursor jumping to the end<span data-mw-comment-end="h-Cursor_jumping_to_the_end-2021-07-27T18:18:00.000Z"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=1" title="Edit section: Cursor jumping to the end">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Ain92-2022-07-09T09:05:00.000Z-Nikki-2021-07-27T18:18:00.000Z","timestamp":"2022-07-09T09:05:00.000Z"}__--><!--__DTCOMMENTCOUNT__5__--><!--__DTAUTHORCOUNT__5__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-Nikki-2021-07-27T18:18:00.000Z--></div></div></h2>
<p><span data-mw-comment-start="" id="c-Nikki-2021-07-27T18:18:00.000Z-Cursor_jumping_to_the_end"></span>I keep having trouble with the cursor jumping to the end of the input. It seems that whenever it automatically uppercases the first letter or removes leading whitespace/underscores, it moves the cursor to the end regardless of where the cursor was before. For example, if the current name is "Example" and the cursor is at the beginning:
</p>
<ul><li>Pressing "a" turns into "AExample"</li>
<li>Pressing the delete key turns into "Xample"</li>
<li>Pasting a lowercase word like "another" turns into "AnotherExample"</li>
<li>Pressing the space bar removes the space</li></ul>
<p>and then the cursor moves to the end.
</p><p>It looks like the problem is caused by <code>sanitizeInput</code> and <code>makeActive</code> in the <code>textchange</code> function. The former changes the capitalisation and strips leading whitespace/underscores, and the latter moves the cursor to the end if <code>actualValue.indexOf( expectedInput )</code> is false, which is the case when the values are the same (<code>indexOf</code> is 0) or when the capitalisation is different (<code>indexOf</code> is -1).
</p><p>- <a href="/wiki/User:Nikki" title="User:Nikki">Nikki</a> (<a href="/wiki/User_talk:Nikki" title="User talk:Nikki"><span class="signature-talk">talk</span></a>) 18:18, 27 July 2021 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2021-07-27T18:18:00.000Z&quot;,&quot;author&quot;:&quot;Nikki&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-Nikki-2021-07-27T18:18:00.000Z-Cursor_jumping_to_the_end&quot;,&quot;replies&quot;:[&quot;c-Enyavar-2022-01-27T13:58:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;c-Tuvalkin-2022-01-28T22:07:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;c-PeterWD-2022-05-21T11:01:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;c-Ain92-2022-07-09T09:05:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;]}"><span id="ooui-php-1" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Nikki-2021-07-27T18:18:00.000Z-Cursor_jumping_to_the_end"></span>
</p>
<dl><dd><span data-mw-comment-start="" id="c-Enyavar-2022-01-27T13:58:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span>+1, this bug is annoying. Let's hope it will be solved eventually. --<a href="/wiki/User:Enyavar" title="User:Enyavar">Enyavar</a> (<a href="/wiki/User_talk:Enyavar" title="User talk:Enyavar"><span class="signature-talk">talk</span></a>) 13:58, 27 January 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-01-27T13:58:00.000Z&quot;,&quot;author&quot;:&quot;Enyavar&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-Enyavar-2022-01-27T13:58:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-2" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Enyavar-2022-01-27T13:58:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span></dd>
<dd><span data-mw-comment-start="" id="c-Tuvalkin-2022-01-28T22:07:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span>+1 indeed! -- <a href="/wiki/User:Tuvalkin" title="User:Tuvalkin">Tuválkin</a> <a href="/wiki/User_talk:Tuvalkin" title="User talk:Tuvalkin">✉</a> <a href="/wiki/Special:Contributions/Tuvalkin" title="Special:Contributions/Tuvalkin">✇</a> 22:07, 28 January 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-01-28T22:07:00.000Z&quot;,&quot;author&quot;:&quot;Tuvalkin&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-Tuvalkin-2022-01-28T22:07:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-3" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Tuvalkin-2022-01-28T22:07:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span></dd>
<dd><span data-mw-comment-start="" id="c-PeterWD-2022-05-21T11:01:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span>+1 Can we please get some action on this - I mistakenly long thought it was an esoteric 'feature' <a href="/wiki/User:PeterWD" title="User:PeterWD">PeterWD</a> (<a href="/wiki/User_talk:PeterWD" title="User talk:PeterWD"><span class="signature-talk">talk</span></a>) 11:01, 21 May 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-05-21T11:01:00.000Z&quot;,&quot;author&quot;:&quot;PeterWD&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-PeterWD-2022-05-21T11:01:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-4" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-PeterWD-2022-05-21T11:01:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span></dd></dl>
<ul><li><span data-mw-comment-start="" id="c-Ain92-2022-07-09T09:05:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span>Let me absolutely second that! <a href="/wiki/User:Ain92" title="User:Ain92">Ain92</a> (<a href="/wiki/User_talk:Ain92" title="User talk:Ain92"><span class="signature-talk">talk</span></a>) 09:05, 9 July 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-07-09T09:05:00.000Z&quot;,&quot;author&quot;:&quot;Ain92&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-Ain92-2022-07-09T09:05:00.000Z-Nikki-2021-07-27T18:18:00.000Z&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-5" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Ain92-2022-07-09T09:05:00.000Z-Nikki-2021-07-27T18:18:00.000Z"></span></li></ul>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-Umherirrender-2022-01-14T21:29:00.000Z--><!--__DTSUBSCRIBELINK__h-Umherirrender-2022-01-14T21:29:00.000Z--><span class="mw-headline" id="API_deprecation_notice_about_rvslots" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-Umherirrender-2022-01-14T21:29:00.000Z&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-API_deprecation_notice_about_rvslots-2022-01-14T21:29:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Umherirrender-2022-01-14T21:29:00.000Z-API_deprecation_notice_about_rvslots&quot;]}"><span data-mw-comment-start="" id="h-API_deprecation_notice_about_rvslots-2022-01-14T21:29:00.000Z"></span>API deprecation notice about rvslots<span data-mw-comment-end="h-API_deprecation_notice_about_rvslots-2022-01-14T21:29:00.000Z"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=2" title="Edit section: API deprecation notice about rvslots">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Umherirrender-2022-01-14T21:29:00.000Z-API_deprecation_notice_about_rvslots","timestamp":"2022-01-14T21:29:00.000Z"}__--><!--__DTCOMMENTCOUNT__1__--><!--__DTAUTHORCOUNT__1__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-Umherirrender-2022-01-14T21:29:00.000Z--></div></div></h2>
<p><span data-mw-comment-start="" id="c-Umherirrender-2022-01-14T21:29:00.000Z-API_deprecation_notice_about_rvslots"></span>The response contains an api deprecation notice.
</p>
<blockquote class="templatequote"><p><span class="language">"Because "rvslots" was not specified, a legacy format has been used for the output. This format is deprecated, and in the future the new format will always be used."</span>
</p></blockquote>
<p>For both use of <code>rvprop=content</code> the param <code>rvslots=main</code> should be added. Also <code>page.revisions[ 0 ][ '*' ]</code> must changed to <code>page.revisions[ 0 ][ 'slots' ][ 'main' ][ '*' ]</code>.
The mediainfo slot does not support categories and is ignored in that case. This is untested. <a href="/wiki/User:Umherirrender" title="User:Umherirrender">Der Umherirrende</a> (<a href="/wiki/User_talk:Umherirrender" title="User talk:Umherirrender"><span class="signature-talk">talk</span></a>) 21:29, 14 January 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-01-14T21:29:00.000Z&quot;,&quot;author&quot;:&quot;Umherirrender&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-Umherirrender-2022-01-14T21:29:00.000Z-API_deprecation_notice_about_rvslots&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-6" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Umherirrender-2022-01-14T21:29:00.000Z-API_deprecation_notice_about_rvslots"></span>
</p>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-Enyavar-2022-02-04T23:00:00.000Z--><!--__DTSUBSCRIBELINK__h-Enyavar-2022-02-04T23:00:00.000Z--><span class="mw-headline" id="Dropped-categories_bug" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-Enyavar-2022-02-04T23:00:00.000Z&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Dropped-categories_bug-2022-02-04T23:00:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Enyavar-2022-02-04T23:00:00.000Z-Dropped-categories_bug&quot;]}"><span data-mw-comment-start="" id="h-Dropped-categories_bug-2022-02-04T23:00:00.000Z"></span>Dropped-categories bug<span data-mw-comment-end="h-Dropped-categories_bug-2022-02-04T23:00:00.000Z"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=3" title="Edit section: Dropped-categories bug">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Enyavar-2022-06-11T16:45:00.000Z-\u0160J\u016f-2022-06-11T15:01:00.000Z","timestamp":"2022-06-11T16:45:00.000Z"}__--><!--__DTCOMMENTCOUNT__3__--><!--__DTAUTHORCOUNT__2__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-Enyavar-2022-02-04T23:00:00.000Z--></div></div></h2>
<div class="thumb tright"><div class="thumbinner" style="width:352px;"><span data-mw-comment-start="" id="c-Enyavar-2022-02-04T23:00:00.000Z-Dropped-categories_bug"></span><a href="/wiki/File:2022-01-27_Bug_Report_on_HotCat_Tool.png" class="image"><img alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/2022-01-27_Bug_Report_on_HotCat_Tool.png/350px-2022-01-27_Bug_Report_on_HotCat_Tool.png" decoding="async" width="350" height="154" class="thumbimage" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/2022-01-27_Bug_Report_on_HotCat_Tool.png/525px-2022-01-27_Bug_Report_on_HotCat_Tool.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/2022-01-27_Bug_Report_on_HotCat_Tool.png/700px-2022-01-27_Bug_Report_on_HotCat_Tool.png 2x" data-file-width="1040" data-file-height="458"/></a>  <div class="thumbcaption"><div class="magnify"><a href="/wiki/File:2022-01-27_Bug_Report_on_HotCat_Tool.png" class="internal" title="Enlarge"></a></div>three-step demonstration of the HotCat-bug</div></div></div>
<p><a href="/wiki/Commons:Village_pump/Archive/2022/01#HotCat_bugs" title="Commons:Village pump/Archive/2022/01">As first reported here</a>, there is an annoying tendency to change and then drop user-input categories, seemingly at random. Upon confirming the new HotCategorized categories with the "Save" button, it may happen that the first of the new categories gets exchanged for another new category; which then leads subsequently to dropping the one that gets changed in the Edit dialog. This may or may not have something to do with the editing line still open (it gets closed automatically when you use the Save button). This bug has undone some work from me for months, but I couldn't reproduce it until today, in the case of the attached screenshot-series. Sorry that I cannot provide any technical insight into the problem. --<a href="/wiki/User:Enyavar" title="User:Enyavar">Enyavar</a> (<a href="/wiki/User_talk:Enyavar" title="User talk:Enyavar"><span class="signature-talk">talk</span></a>) 23:00, 4 February 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-02-04T23:00:00.000Z&quot;,&quot;author&quot;:&quot;Enyavar&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-Enyavar-2022-02-04T23:00:00.000Z-Dropped-categories_bug&quot;,&quot;replies&quot;:[&quot;c-\u0160J\u016f-2022-06-11T15:01:00.000Z-Enyavar-2022-02-04T23:00:00.000Z&quot;]}"><span id="ooui-php-7" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Enyavar-2022-02-04T23:00:00.000Z-Dropped-categories_bug"></span>
</p>
<dl><dd><span class="template-ping"><span data-mw-comment-start="" id="c-ŠJů-2022-06-11T15:01:00.000Z-Enyavar-2022-02-04T23:00:00.000Z"></span>@<a href="/wiki/User:Enyavar" title="User:Enyavar">Enyavar</a>: </span> Did you mean <a href="https://phabricator.wikimedia.org/T222376" class="extiw" title="phab:T222376">this bug</a>? Standardly, when categories are edited using HotCat, more fields can be opened (without OK click) and the "Save" button saves all changes correctly. However, when more than one target categories are redirected, the screen displays all of them correctly redirected at first, but in the next step when the whole source page is opened to edit, only the last of the redirected category tags is kept and all the previous are disappeared. Multiple <a href="/wiki/Help:Gadget-HotCat#Category_redirects_and_disambiguations" title="Help:Gadget-HotCat">redirects</a> don't work correctly. Probably, some variable used for redirects is not distinguished and is ovewritten by the next one. To prevent this, the user must first confirm each category change separately with the OK button before pressing Save button for the entire change group (if he is not sure that none of the newly linked categories is redirected).</dd></dl>
<dl><dd><span class="template-ping">@<a href="/wiki/User:Lupo" title="User:Lupo">Lupo</a>: </span> Unfortunately, Phabricator reportedly has no project in which this bug could be solved. I was referred here to this local site.--<a href="/wiki/User:%C5%A0J%C5%AF" title="User:ŠJů">ŠJů</a> (<a href="/wiki/User_talk:%C5%A0J%C5%AF" title="User talk:ŠJů"><span class="signature-talk">talk</span></a>) 15:01, 11 June 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-06-11T15:01:00.000Z&quot;,&quot;author&quot;:&quot;\u0160J\u016f&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-\u0160J\u016f-2022-06-11T15:01:00.000Z-Enyavar-2022-02-04T23:00:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Enyavar-2022-06-11T16:45:00.000Z-\u0160J\u016f-2022-06-11T15:01:00.000Z&quot;]}"><span id="ooui-php-8" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-ŠJů-2022-06-11T15:01:00.000Z-Enyavar-2022-02-04T23:00:00.000Z"></span></dd></dl>
<dl><dd><dl><dd><span data-mw-comment-start="" id="c-Enyavar-2022-06-11T16:45:00.000Z-ŠJů-2022-06-11T15:01:00.000Z"></span>It makes sense to me now that the category-redirects have to do with this. I am treading much more carefully with this already and more often needlessly click "ok". The rate this bug happens to me has dropped to only once a day or so, and I usually catch it after it happened. What I am not sure about is that bit with <i>"more than one target categories are redirected"</i>. I am certain I have had this bug two days ago with just two categories, and only the latter one was a redirect which I had confirmed, and the first one was the correct category which was still dropped upon saving. --<a href="/wiki/User:Enyavar" title="User:Enyavar">Enyavar</a> (<a href="/wiki/User_talk:Enyavar" title="User talk:Enyavar"><span class="signature-talk">talk</span></a>) 16:45, 11 June 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-06-11T16:45:00.000Z&quot;,&quot;author&quot;:&quot;Enyavar&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:3,&quot;id&quot;:&quot;c-Enyavar-2022-06-11T16:45:00.000Z-\u0160J\u016f-2022-06-11T15:01:00.000Z&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-9" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Enyavar-2022-06-11T16:45:00.000Z-ŠJů-2022-06-11T15:01:00.000Z"></span></dd></dl></dd></dl>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-Bebiezaza-2022-05-26T15:53:00.000Z--><!--__DTSUBSCRIBELINK__h-Bebiezaza-2022-05-26T15:53:00.000Z--><span class="mw-headline" id="Global_Localization_for_Thai" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-Bebiezaza-2022-05-26T15:53:00.000Z&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Global_Localization_for_Thai-2022-05-26T15:53:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Bebiezaza-2022-05-26T15:53:00.000Z-Global_Localization_for_Thai&quot;]}"><span data-mw-comment-start="" id="h-Global_Localization_for_Thai-2022-05-26T15:53:00.000Z"></span>Global Localization for Thai<span data-mw-comment-end="h-Global_Localization_for_Thai-2022-05-26T15:53:00.000Z"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=4" title="Edit section: Global Localization for Thai">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Bebiezaza-2022-05-26T15:53:00.000Z-Global_Localization_for_Thai","timestamp":"2022-05-26T15:53:00.000Z"}__--><!--__DTCOMMENTCOUNT__1__--><!--__DTAUTHORCOUNT__1__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-Bebiezaza-2022-05-26T15:53:00.000Z--></div></div></h2>
<p><span data-mw-comment-start="" id="c-Bebiezaza-2022-05-26T15:53:00.000Z-Global_Localization_for_Thai"></span>HotCat: Global Thai Localization
</p><p>Based upon <a href="https://en.wikipedia.org/wiki/th:MediaWiki:Gadget-HotCat.js/local_defaults" class="extiw" title="w:th:MediaWiki:Gadget-HotCat.js/local defaults">w:th:MediaWiki:Gadget-HotCat.js/local_defaults</a> (<a href="https://en.wikipedia.org/wiki/th:Special:Diff/9337615" class="extiw" title="w:th:Special:Diff/9337615">Diff ID 9337615</a>), which is the main localization of HotCat for Thai language Wikis. Most of the texts below are unchanged from the original.
</p>
<div class="tpl-hidden mw-collapsible mw-collapsed">
<style data-mw-deduplicate="TemplateStyles:r695744913">.mw-parser-output .tpl-hidden{clear:both}.mw-parser-output .tpl-hidden>.mw-collapsible-toggle{float:none}.mw-parser-output .tpl-hidden::before{display:none}html.client-js .mw-parser-output .tpl-hidden-headertext{padding-left:18px}.mw-parser-output .tpl-hidden.mw-made-collapsible>.mw-collapsible-toggle>.tpl-hidden-headertext{background-image:url("//upload.wikimedia.org/wikipedia/commons/1/10/MediaWiki_Vector_skin_action_arrow.png");background-position:left 50%;background-repeat:no-repeat}.mw-parser-output .tpl-hidden.mw-made-collapsible.mw-collapsed>.mw-collapsible-toggle>.tpl-hidden-headertext{background-image:url("//upload.wikimedia.org/wikipedia/commons/4/41/MediaWiki_Vector_skin_right_arrow.png")}</style>
<div class="mw-collapsible-toggle" style="font-weight:bold; background-color:transparent; text-align:center;"><span class="tpl-hidden-headertext">Thai localization</span></div>
<div class="mw-collapsible-content" style="font-weight:normal; background:transparent; text-align:start;">
<div class="mw-highlight mw-highlight-lang-javascript mw-content-ltr" dir="ltr"><pre><span></span><span class="c1">//&lt;syntaxhighlight lang="javascript"></span>
<span class="cm">/*</span>
<span class="cm"> * HotCat: Global Thai Localization</span>
<span class="cm"> * </span>
<span class="cm"> * Based upon //th.wikipedia.org/w/index.php?title=MediaWiki:Gadget-HotCat.js/local_defaults</span>
<span class="cm"> * , which is the main localization of HotCat for Thai language Wikis. Most of the texts are </span>
<span class="cm"> * unchanged from the original in the first revision of this JS page.</span>
<span class="cm"> * </span>
<span class="cm"> * As of the creation of this page, some sister projects localization have not been updated </span>
<span class="cm"> * to the current revision (ID 9337615) of Thai Wikipedia's localization yet.</span>
<span class="cm"> * </span>
<span class="cm"> * (Credits according to local_defaults' history in each projects)</span>
<span class="cm"> * Credits WP: B20180, Jutiphan, Nullzero</span>
<span class="cm"> * Credits WS: Sasakubo1717, Geonuch</span>
<span class="cm"> * Credits WB: Sasakubo1717, Geonuch</span>
<span class="cm"> * Credits WikT: Sasakubo1717, Octahedron80</span>
<span class="cm"> * Credits WQ: Sasakubo1717, B20180</span>
<span class="cm"> * Credits UN: Patzagorn Y? (Patsagorn Y.)</span>
<span class="cm"> */</span>
<span class="cm">/* global HotCat */</span>

<span class="c1">// Layout from ../en</span>
<span class="c1">// Localizations of a few HotCat user interface texts.</span>
<span class="k">if</span> <span class="p">(</span><span class="nb">window</span><span class="p">.</span><span class="nx">HotCat</span><span class="p">)</span> <span class="p">{</span>
	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">commit</span>      <span class="o">=</span> <span class="s1">'บันทึก'</span><span class="p">;</span>
	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">ok</span>          <span class="o">=</span> <span class="s1">'ตกลง'</span><span class="p">;</span>
	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cancel</span>      <span class="o">=</span> <span class="s1">'ยกเลิก'</span><span class="p">;</span>
	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">multi_error</span> <span class="o">=</span> <span class="s1">'ไม่สามารถดึงข้อความที่ต้องแก้ไขจากระบบได้ การเปลี่ยนหมวดหมู่ไม่สามารถดำเนินการได้ ขออภัยในความไม่สะดวก'</span><span class="p">;</span>

	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">categories</span> <span class="o">=</span> <span class="s1">'หมวดหมู่'</span><span class="p">;</span>

    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">engine_names</span><span class="p">.</span><span class="nx">searchindex</span> <span class="o">=</span> <span class="s1">'ดัชนีการค้นหา'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">engine_names</span><span class="p">.</span><span class="nx">pagelist</span>    <span class="o">=</span> <span class="s1">'รายการหน้าทั้งหมด'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">engine_names</span><span class="p">.</span><span class="nx">combined</span>    <span class="o">=</span> <span class="s1">'ค้นหารวมกลุ่ม'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">engine_names</span><span class="p">.</span><span class="nx">subcat</span>      <span class="o">=</span> <span class="s1">'หมวดหมู่ย่อย'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">engine_names</span><span class="p">.</span><span class="nx">parentcat</span>   <span class="o">=</span> <span class="s1">'หมวดหมู่หลัก'</span><span class="p">;</span>
    
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">change</span>  <span class="o">=</span> <span class="s1">'แก้ไข'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">remove</span>  <span class="o">=</span> <span class="s1">'นำออก'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">add</span>     <span class="o">=</span> <span class="s1">'เพิ่มหมวดหมู่ใหม่'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">restore</span> <span class="o">=</span> <span class="s1">'ย้อนการแก้ไข'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">undo</span>    <span class="o">=</span> <span class="s1">'ย้อนการแก้ไข'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">down</span>    <span class="o">=</span> <span class="s1">'เปิดหน้าต่างแก้ไขและแสดงหมวดหมู่ย่อย'</span><span class="p">;</span>
    <span class="nx">HotCat</span><span class="p">.</span><span class="nx">tooltips</span><span class="p">.</span><span class="nx">up</span>      <span class="o">=</span> <span class="s1">'เปิดหน้าต่างแก้ไขและแสดงหมวดหมู่หลัก'</span><span class="p">;</span>

	<span class="nx">HotCat</span><span class="p">.</span><span class="nx">multi_tooltip</span>    <span class="o">=</span> <span class="s1">'แก้ไขหลายหมวดหมู่พร้อมกัน'</span><span class="p">;</span>

	<span class="c1">// Localize these messages to the main language of your Wiki.</span>
    <span class="c1">//</span>
    <span class="c1">// TODO FOR LOCAL: According to //commons.wikimedia.org/wiki/Help:Gadget-HotCat#Localization , this should be </span>
    <span class="c1">// copied over to ((wgServer + /w/index.php?title=MediaWiki:Gadget-HotCat.js/local_defaults))</span>
    <span class="c1">// TODO FOR LOCAL: Replace next line with: if (window.HotCat) {</span>
	<span class="k">if</span> <span class="p">(</span><span class="nx">mw</span><span class="p">.</span><span class="nx">config</span><span class="p">.</span><span class="nx">get</span><span class="p">(</span><span class="s1">'wgContentLanguage'</span><span class="p">)</span> <span class="o">===</span> <span class="s1">'th'</span><span class="p">)</span> <span class="p">{</span>

		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_removed</span>      <span class="o">=</span> <span class="s1">'ลบ[[:หมวดหมู่:$1]]'</span><span class="p">;</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">template_removed</span> <span class="o">=</span> <span class="s1">''</span><span class="p">;</span> <span class="c1">// According to original local localization, this is unused and is set as null.</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_added</span>        <span class="o">=</span> <span class="s1">'เพิ่ม[[:หมวดหมู่:$1]]'</span><span class="p">;</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_keychange</span>    <span class="o">=</span> <span class="s1">'เปลี่ยนการเรียงลำดับใน[[:หมวดหมู่:$1]] ให้เรียงด้วย "$2"'</span><span class="p">;</span> <span class="c1">// $2 is the new key</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_notFound</span>     <span class="o">=</span> <span class="s1">'ไม่พบหมวดหมู่ "$1"'</span><span class="p">;</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_exists</span>       <span class="o">=</span> <span class="s1">'มีหมวดหมู่ $1 อยู่แล้ว ไม่เพิ่มหมวดหมู่'</span><span class="p">;</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">cat_resolved</span>     <span class="o">=</span> <span class="s1">' (แก้เปลี่ยนทางของ[[:หมวดหมู่: $1]]แล้ว)'</span><span class="p">;</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">uncat_removed</span>    <span class="o">=</span> <span class="s1">'ลบป้าย {{ต้องการหมวดหมู่}}'</span><span class="p">;</span>
        <span class="c1">// ----</span>
		<span class="c1">// Some text to append to the edit summary (tagline). Named 'using' for historical reasons.</span>
        <span class="c1">// --</span>
        <span class="c1">// TODO FOR LOCAL: Uncomment |HotCat.messages.using| and edit it for each sister projects</span>
        <span class="c1">// Use local_defaults, below is from Thai Wikipedia, but sister projects use different ones</span>
		<span class="c1">// HotCat.messages.using            = 'ด้วย[[วิกิพีเดีย:ฮอทแคต|ฮอทแคต]]';</span>
        <span class="c1">// ----</span>
		<span class="c1">// $1 is replaced by a number. If your language has several plural forms (c.f. [[:en:Dual (grammatical form)]]);</span>
		<span class="c1">// you can set this to an array of strings suitable for passing to mw.language.configPlural().</span>
		<span class="c1">// If that function doesn't exist, HotCat will simply fall back to using the last</span>
		<span class="c1">// entry in the array.</span>
		<span class="nx">HotCat</span><span class="p">.</span><span class="nx">messages</span><span class="p">.</span><span class="nx">multi_change</span>     <span class="o">=</span> <span class="s1">'$1 หมวดหมู่'</span><span class="p">;</span>

        <span class="c1">// These are in the local localization, but not on global en loc. These are probably </span>
        <span class="c1">// still in use to this day due to regex difference in |HotCat.uncat_regexp|</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">category_regexp</span>     <span class="o">=</span> <span class="s1">'หมวดหมู่'</span><span class="p">;</span> <span class="c1">//ไม่ใช้ Regex เพราะปกติการเพิ่มหมวดหมู่พิมพ์เป็นภาษาไทย แต่หากเดิมเนมสเปซนี้พิมพ์เป็นชื่ออื่น HotCat จะไม่แก้หมวดหมู่หรือแก้คำให้</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">category_canonical</span>  <span class="o">=</span> <span class="s1">'หมวดหมู่'</span><span class="p">;</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">disambig_category</span>   <span class="o">=</span> <span class="s1">'แก้ความกำกวม'</span><span class="p">;</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">redir_category</span>      <span class="o">=</span> <span class="s1">'หมวดหมู่เปลี่ยนทาง'</span><span class="p">;</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">uncat_regexp</span> <span class="o">=</span> <span class="sr">/\{\{(uncategorized|ต้องการหมวดหมู่)\}\}|\{\{(((article|multiple)\ )?issues?|ข้อควรปรับปรุงของบทความ|ขคปป\.)\|(uncategorized|ต้องการหมวดหมู่)=yes\}\}|\|(uncategorized|ต้องการหมวดหมู่)=yes/i</span> <span class="p">;</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">template_regexp</span>     <span class="o">=</span> <span class="s1">'แม่แบบ'</span><span class="p">;</span>
        <span class="nx">HotCat</span><span class="p">.</span><span class="nx">template_categories</span> <span class="o">=</span> <span class="p">{};</span>
	<span class="p">}</span>
<span class="p">}</span>

<span class="c1">//&lt;/syntaxhighlight></span>
</pre></div>
</div></div>
<p>Add it to <a href="/w/index.php?title=MediaWiki:Gadget-HotCat.js/th&amp;action=edit&amp;redlink=1" class="new" title="MediaWiki:Gadget-HotCat.js/th (page does not exist)">MediaWiki:Gadget-HotCat.js/th</a> please. Thanks. --<a href="/wiki/User:Bebiezaza" title="User:Bebiezaza">Bebiezaza</a> (<a href="/wiki/User_talk:Bebiezaza" title="User talk:Bebiezaza"><span class="signature-talk">talk</span></a>) 15:53, 26 May 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-05-26T15:53:00.000Z&quot;,&quot;author&quot;:&quot;Bebiezaza&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-Bebiezaza-2022-05-26T15:53:00.000Z-Global_Localization_for_Thai&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-10" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Bebiezaza-2022-05-26T15:53:00.000Z-Global_Localization_for_Thai"></span>
</p>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-Ain92-2022-07-09T09:12:00.000Z--><!--__DTSUBSCRIBELINK__h-Ain92-2022-07-09T09:12:00.000Z--><span class="mw-headline" id="A_hint_to_a_user_attempting_to_remove_a_sort_key" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-Ain92-2022-07-09T09:12:00.000Z&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-A_hint_to_a_user_attempting_to_remove_a_sort_key-2022-07-09T09:12:00.000Z&quot;,&quot;replies&quot;:[&quot;c-Ain92-2022-07-09T09:12:00.000Z-A_hint_to_a_user_attempting_to_remove_a_sort_key&quot;]}"><span data-mw-comment-start="" id="h-A_hint_to_a_user_attempting_to_remove_a_sort_key-2022-07-09T09:12:00.000Z"></span>A hint to a user attempting to remove a sort key<span data-mw-comment-end="h-A_hint_to_a_user_attempting_to_remove_a_sort_key-2022-07-09T09:12:00.000Z"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=5" title="Edit section: A hint to a user attempting to remove a sort key">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Ain92-2022-07-09T09:12:00.000Z-A_hint_to_a_user_attempting_to_remove_a_sort_key","timestamp":"2022-07-09T09:12:00.000Z"}__--><!--__DTCOMMENTCOUNT__1__--><!--__DTAUTHORCOUNT__1__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-Ain92-2022-07-09T09:12:00.000Z--></div></div></h2>
<p><span data-mw-comment-start="" id="c-Ain92-2022-07-09T09:12:00.000Z-A_hint_to_a_user_attempting_to_remove_a_sort_key"></span>As discussed in <a href="/wiki/MediaWiki_talk:Gadget-HotCat.js/Archive02#Removing_of_sort_key" title="MediaWiki talk:Gadget-HotCat.js/Archive02">MediaWiki_talk:Gadget-HotCat.js/Archive02#Removing_of_sort_key</a>, sort key removal is quite esoteric in HotCat (I only found our the right way today myself). Could we please notify user what's happening if "an existing sort key from the source is preserved when performing the edit" despite the user removing it? TBH, I would prefer that the sort key would actually be removed in that case in accordance to the <a href="https://en.wikipedia.org/wiki/principle_of_least_astonishment" class="extiw" title="w:principle of least astonishment">principle of least astonishment</a>, but can accept if it's not possible for some technical reasons. <a href="/wiki/User:Ain92" title="User:Ain92">Ain92</a> (<a href="/wiki/User_talk:Ain92" title="User talk:Ain92"><span class="signature-talk">talk</span></a>) 09:12, 9 July 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;2022-07-09T09:12:00.000Z&quot;,&quot;author&quot;:&quot;Ain92&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-Ain92-2022-07-09T09:12:00.000Z-A_hint_to_a_user_attempting_to_remove_a_sort_key&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-11" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Ain92-2022-07-09T09:12:00.000Z-A_hint_to_a_user_attempting_to_remove_a_sort_key"></span>
</p>
<h2 class="ext-discussiontools-init-section"><!--__DTSUBSCRIBEBUTTONDESKTOP__h-BlunderGhoul-20220825202400--><!--__DTSUBSCRIBELINK__h-BlunderGhoul-20220825202400--><span class="mw-headline" id="Mobile_compatibility" data-mw-comment="{&quot;headingLevel&quot;:2,&quot;name&quot;:&quot;h-BlunderGhoul-20220825202400&quot;,&quot;type&quot;:&quot;heading&quot;,&quot;level&quot;:0,&quot;id&quot;:&quot;h-Mobile_compatibility-20220825202400&quot;,&quot;replies&quot;:[&quot;c-BlunderGhoul-20220825202400-Mobile_compatibility&quot;]}"><span data-mw-comment-start="" id="h-Mobile_compatibility-20220825202400"></span>Mobile compatibility<span data-mw-comment-end="h-Mobile_compatibility-20220825202400"></span></span><span class="mw-editsection"><span class="mw-editsection-bracket">[</span><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=6" title="Edit section: Mobile compatibility">edit</a><span class="mw-editsection-bracket">]</span></span><!--__DTELLIPSISBUTTON__--><div class="ext-discussiontools-init-section-bar"><div class="ext-discussiontools-init-section-metadata"><!--__DTLATESTCOMMENTTHREAD__{"id":"c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400","timestamp":"20220826211300"}__--><!--__DTCOMMENTCOUNT__2__--><!--__DTAUTHORCOUNT__2__--></div><div class="ext-discussiontools-init-section-actions"><!--__DTSUBSCRIBEBUTTONMOBILE__h-BlunderGhoul-20220825202400--></div></div></h2>
<p><span data-mw-comment-start="" id="c-BlunderGhoul-20220825202400-Mobile_compatibility"></span>I know full well that this gadget was made mobile-friendly quite a while ago. Exactly when did it happen? And how can I make Wiktionary's version of HotCat mobile-friendly as well? (I'm really horrible with code, by the way.) <a href="/wiki/User:BlunderGhoul" title="User:BlunderGhoul">BlunderGhoul</a> (<a href="/wiki/User_talk:BlunderGhoul" title="User talk:BlunderGhoul"><span class="signature-talk">talk</span></a>) 20:24, 25 August 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;20220825202400&quot;,&quot;author&quot;:&quot;BlunderGhoul&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:1,&quot;id&quot;:&quot;c-BlunderGhoul-20220825202400-Mobile_compatibility&quot;,&quot;replies&quot;:[&quot;c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400&quot;]}"><span id="ooui-php-12" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-BlunderGhoul-20220825202400-Mobile_compatibility"></span>
</p>
<dl><dd><span data-mw-comment-start="" id="c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400"></span>For others who are not <a class="external text" href="https://en.wiktionary.org/w/index.php?title=Special:Log&amp;logid=51132253">infinitely blocked</a> on Wiktionary: <a class="external text" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki:Gadgets-definition&amp;diff=568196393&amp;oldid=556918096">it was enabled on mobile in June last year</a>. I don’t know if any other steps were necessary, but I don’t want to spend more time finding it out until someone actually needs it. —<a href="/wiki/User:Tacsipacsi" title="User:Tacsipacsi">Tacsipacsi</a> (<a href="/wiki/User_talk:Tacsipacsi" title="User talk:Tacsipacsi"><span class="signature-talk">talk</span></a>) 21:13, 26 August 2022 (UTC)<span class="ext-discussiontools-init-replylink-buttons" data-mw-comment="{&quot;timestamp&quot;:&quot;20220826211300&quot;,&quot;author&quot;:&quot;Tacsipacsi&quot;,&quot;type&quot;:&quot;comment&quot;,&quot;level&quot;:2,&quot;id&quot;:&quot;c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400&quot;,&quot;replies&quot;:[]}"><span id="ooui-php-13" class="ext-discussiontools-init-replybutton oo-ui-widget oo-ui-widget-enabled oo-ui-buttonElement oo-ui-buttonElement-frameless oo-ui-labelElement oo-ui-flaggedElement-progressive oo-ui-buttonWidget" data-ooui='{"_":"OO.ui.ButtonWidget","rel":["nofollow"],"framed":false,"label":"Reply","flags":["progressive"],"classes":["ext-discussiontools-init-replybutton"]}'><a role="button" tabindex="0" rel="nofollow" class="oo-ui-buttonElement-button"><span class="oo-ui-iconElement-icon oo-ui-iconElement-noIcon oo-ui-image-progressive"></span><span class="oo-ui-labelElement-label">Reply</span><span class="oo-ui-indicatorElement-indicator oo-ui-indicatorElement-noIndicator oo-ui-image-progressive"></span></a></span><span class="ext-discussiontools-init-replylink-bracket">[</span><a class="ext-discussiontools-init-replylink-reply" role="button" tabindex="0" href="">reply</a><span class="ext-discussiontools-init-replylink-bracket">]</span></span><span data-mw-comment-end="c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400"></span></dd></dl><!--__DTLATESTCOMMENTPAGE__{"id":"c-Tacsipacsi-20220826211300-BlunderGhoul-20220825202400","timestamp":"20220826211300","author":"Tacsipacsi","heading":{"headingLevel":2,"name":"h-BlunderGhoul-20220825202400","type":"heading","level":0,"id":"h-Mobile_compatibility-20220825202400","replies":["c-BlunderGhoul-20220825202400-Mobile_compatibility"],"text":"Mobile compatibility","linkableTitle":"Mobile compatibility"}}__-->
<!-- 
NewPP limit report
Parsed by mw1409
Cached time: 20221015183737
Cache expiry: 555
Reduced expiry: true
Complications: [show‐toc]
DiscussionTools time usage: 0.026 seconds
CPU time usage: 0.154 seconds
Real time usage: 0.226 seconds
Preprocessor visited node count: 1066/1000000
Post‐expand include size: 77155/2097152 bytes
Template argument size: 2065/2097152 bytes
Highest expansion depth: 20/100
Expensive parser function count: 7/500
Unstrip recursion depth: 0/20
Unstrip post‐expand size: 19258/5000000 bytes
Lua time usage: 0.058/10.000 seconds
Lua memory usage: 1603545/52428800 bytes
Number of Wikibase entities loaded: 0/400
-->
<!--
Transclusion expansion time report (%,ms,calls,template)
100.00%  133.636      1 -total
 71.65%   95.745      2 Template:Autotranslate
 66.92%   89.423      1 Template:Gadget-talk
 52.19%   69.746      3 Template:Tmbox
 11.45%   15.296      1 Template:Archives
 10.88%   14.537      1 Template:Lang_links_cheap
  8.83%   11.798      1 Template:Gadget-desc
  8.02%   10.720      1 Template:Lang_links
  7.29%    9.744      1 Template:Re
  6.71%    8.970      2 Template:Pg
-->

<!-- Saved in parser cache with key commonswiki:pcache:idhash:3190584-0!canonical and timestamp 20221015183737 and revision id 685194842.
 -->
</div><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=685194842">https://commons.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=685194842</a>"</div></div>
		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-hidden-catlinks" class="mw-hidden-catlinks mw-hidden-cats-user-shown">Hidden categories: <ul><li><a href="/wiki/Category:Pages_using_deprecated_source_tags" title="Category:Pages using deprecated source tags">Pages using deprecated source tags</a></li><li><a href="/wiki/Category:Gadget_scripts" title="Category:Gadget scripts">Gadget scripts</a></li></ul></div></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-uls" class="mw-list-item active"><a class="uls-trigger" href="#"><span>English</span></a></li><li id="pt-anonuserpage" class="mw-list-item"><span title="The user page for the IP address you are editing as">Not logged in</span></li><li id="pt-anontalk" class="mw-list-item"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n"><span>Talk</span></a></li><li id="pt-anoncontribs" class="mw-list-item"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y"><span>Contributions</span></a></li><li id="pt-createaccount" class="mw-list-item"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=MediaWiki+talk%3AGadget-HotCat.js" title="You are encouraged to create an account and log in; however, it is not mandatory"><span>Create account</span></a></li><li id="pt-login" class="mw-list-item"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=MediaWiki+talk%3AGadget-HotCat.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-mediawiki" class="mw-list-item"><a href="/wiki/MediaWiki:Gadget-HotCat.js" title="View the system message [c]" accesskey="c"><span>Interface page</span></a></li><li id="ca-talk" class="selected mw-list-item"><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js" rel="discussion" title="Discussion about the content page [t]" accesskey="t"><span>Discussion</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-view" class="selected vector-tab-noicon mw-list-item"><a href="/wiki/MediaWiki_talk:Gadget-HotCat.js"><span>View</span></a></li><li id="ca-edit" class="istalk vector-tab-noicon mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit" title="Edit this page [e]" accesskey="e"><span>Edit</span></a></li><li id="ca-addsection" class="vector-tab-noicon mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=edit&amp;section=new" title="Start a new section [+]" accesskey="+"><span>Add topic</span></a></li><li id="ca-history" class="vector-tab-noicon mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=history" title="Past revisions of this page [h]" accesskey="h"><span>History</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/w/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Wikimedia Commons" aria-label="Search Wikimedia Commons" autocapitalize="sentences" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:MediaSearch">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/wiki/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-navigation" class="vector-menu mw-portlet mw-portlet-navigation vector-menu-portal portal" aria-labelledby="p-navigation-label" role="navigation"  >
	<h3
		id="p-navigation-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Navigate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-mainpage-description" class="mw-list-item"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z"><span>Main page</span></a></li><li id="n-welcome" class="mw-list-item"><a href="/wiki/Commons:Welcome"><span>Welcome</span></a></li><li id="n-portal" class="mw-list-item"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things"><span>Community portal</span></a></li><li id="n-village-pump" class="mw-list-item"><a href="/wiki/Commons:Village_pump"><span>Village pump</span></a></li><li id="n-help" class="mw-list-item"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out"><span>Help center</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-participate" class="vector-menu mw-portlet mw-portlet-participate vector-menu-portal portal" aria-labelledby="p-participate-label" role="navigation"  >
	<h3
		id="p-participate-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Participate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-uploadbtn" class="mw-list-item"><a href="/wiki/Special:UploadWizard"><span>Upload file</span></a></li><li id="n-recentchanges" class="mw-list-item"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r"><span>Recent changes</span></a></li><li id="n-latestfiles" class="mw-list-item"><a href="/wiki/Special:NewFiles"><span>Latest files</span></a></li><li id="n-randomimage" class="mw-list-item"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x"><span>Random file</span></a></li><li id="n-contact" class="mw-list-item"><a href="/wiki/Commons:Contact_us"><span>Contact us</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere" class="mw-list-item"><a href="/wiki/Special:WhatLinksHere/MediaWiki_talk:Gadget-HotCat.js" title="A list of all wiki pages that link here [j]" accesskey="j"><span>What links here</span></a></li><li id="t-recentchangeslinked" class="mw-list-item"><a href="/wiki/Special:RecentChangesLinked/MediaWiki_talk:Gadget-HotCat.js" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k"><span>Related changes</span></a></li><li id="t-specialpages" class="mw-list-item"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-permalink" class="mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;oldid=685194842" title="Permanent link to this revision of this page"><span>Permanent link</span></a></li><li id="t-info" class="mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;action=info" title="More information about this page"><span>Page information</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-coll-print_export" class="vector-menu mw-portlet mw-portlet-coll-print_export vector-menu-portal portal" aria-labelledby="p-coll-print_export-label" role="navigation"  >
	<h3
		id="p-coll-print_export-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Print/export</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="coll-create_a_book" class="mw-list-item"><a href="/w/index.php?title=Special:Book&amp;bookcmd=book_creator&amp;referer=MediaWiki+talk%3AGadget-HotCat.js"><span>Create a book</span></a></li><li id="coll-download-as-rl" class="mw-list-item"><a href="/w/index.php?title=Special:DownloadAsPdf&amp;page=MediaWiki_talk%3AGadget-HotCat.js&amp;action=show-download-screen"><span>Download as PDF</span></a></li><li id="t-print" class="mw-list-item"><a href="/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;printable=yes" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li></ul>
		
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
	<li id="footer-info-lastmod"> This page was last edited on 26 August 2022, at 21:13.</li>
	<li id="footer-info-copyright">Files are available under licenses specified on their description page. All structured data from the file namespace is available under the <a href="https://creativecommons.org/publicdomain/zero/1.0/" title="Definition of the Creative Commons CC0 License">Creative Commons CC0 License</a>; all unstructured text is available under the <a href="https://creativecommons.org/licenses/by-sa/3.0/" title="Definition of the Creative Commons Attribution/Share-Alike License">Creative Commons Attribution-ShareAlike License</a>;
additional terms may apply.
By using this site, you agree to the <a href="//foundation.wikimedia.org/wiki/Terms_of_Use" title="Wikimedia Foundation Terms of Use">Terms of Use</a> and the <a href="//foundation.wikimedia.org/wiki/Privacy_policy" title="Wikimedia Foundation Privacy Policy">Privacy Policy</a>.</li>
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/wiki/Commons:Welcome">About Wikimedia Commons</a></li>
	<li id="footer-places-disclaimers"><a href="/wiki/Commons:General_disclaimer">Disclaimers</a></li>
	<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=MediaWiki_talk:Gadget-HotCat.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	<li id="footer-places-developers"><a href="https://developer.wikimedia.org">Developers</a></li>
	<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
	<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/footer/wikimedia-button.png" srcset="/static/images/footer/wikimedia-button-1.5x.png 1.5x, /static/images/footer/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/footer/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/footer/poweredby_mediawiki_132x47.png 1.5x, /static/images/footer/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"discussiontools":{"limitreport-timeusage":"0.026"},"limitreport":{"cputime":"0.154","walltime":"0.226","ppvisitednodes":{"value":1066,"limit":1000000},"postexpandincludesize":{"value":77155,"limit":2097152},"templateargumentsize":{"value":2065,"limit":2097152},"expansiondepth":{"value":20,"limit":100},"expensivefunctioncount":{"value":7,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":19258,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%  133.636      1 -total"," 71.65%   95.745      2 Template:Autotranslate"," 66.92%   89.423      1 Template:Gadget-talk"," 52.19%   69.746      3 Template:Tmbox"," 11.45%   15.296      1 Template:Archives"," 10.88%   14.537      1 Template:Lang_links_cheap","  8.83%   11.798      1 Template:Gadget-desc","  8.02%   10.720      1 Template:Lang_links","  7.29%    9.744      1 Template:Re","  6.71%    8.970      2 Template:Pg"]},"scribunto":{"limitreport-timeusage":{"value":"0.058","limit":"10.000"},"limitreport-memusage":{"value":1603545,"limit":52428800}},"cachereport":{"origin":"mw1409","timestamp":"20221015183737","ttl":555,"transientcontent":true}}});mw.config.set({"wgBackendResponseTime":121,"wgHostname":"mw2276"});});</script>
</body>
</html>
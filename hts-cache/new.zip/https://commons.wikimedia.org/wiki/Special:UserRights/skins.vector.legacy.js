<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>User rights - Wikimedia Commons</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":true,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"52615ca2-b124-4bc0-8b0c-dee4d677331c","wgCSPNonce":false,"wgCanonicalNamespace":"Special","wgCanonicalSpecialPageName":"Userrights","wgNamespaceNumber":-1,"wgPageName":"Special:UserRights/skins.vector.legacy.js","wgTitle":"UserRights/skins.vector.legacy.js","wgCurRevisionId":0,"wgRevisionId":0,"wgArticleId":0,"wgIsArticle":false,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":[],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"Special:UserRights/skins.vector.legacy.js","wgRelevantArticleId":0,"wgIsProbablyEditable":false,"wgRelevantPageIsProbablyEditable":false,"wgVisualEditor":{"pageLanguageCode"
:"en","pageLanguageDir":"ltr","pageVariantFallbacks":"en"},"wgMFDisplayWikibaseDescriptions":{"search":true,"watchlist":true,"tagline":true,"nearby":true},"wgWMESchemaEditAttemptStepOversample":false,"wgWMEPageLength":0,"wgNoticeProject":"commons","wgVector2022PreviewPages":[],"wgMediaViewerOnClick":true,"wgMediaViewerEnabledByDefault":false,"wgULSCurrentAutonym":"English","wgEditSubmitButtonLabelPublish":true,"wbmiDefaultProperties":["P180"],"wbmiPropertyTitles":{"P180":"Items portrayed in this file"},"wbmiPropertyTypes":{"P180":"wikibase-item"},"wbmiRepoApiUrl":"/w/api.php","wbmiHelpUrls":{"P180":"https://commons.wikimedia.org/wiki/Special:MyLanguage/Commons:Depicts"},"wbmiExternalEntitySearchBaseUri":"https://www.wikidata.org/w/api.php","wbmiSupportedDataTypes":["wikibase-item","string","quantity","time","monolingualtext","external-id","globe-coordinate","url"],"wgCentralAuthMobileDomain":false,"wgULSPosition":"personal","wgULSisCompactLinksEnabled":true};RLSTATE={
"ext.gadget.Long-Image-Names-in-Categories":"ready","ext.gadget.uploadWizardMobile":"ready","ext.globalCssJs.user.styles":"ready","site.styles":"ready","user.styles":"ready","ext.globalCssJs.user":"ready","user":"ready","user.options":"loading","mediawiki.special":"ready","mediawiki.helplink":"ready","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready","ext.wikimediaBadges":"ready","ext.uls.pt":"ready"};RLPAGEMODULES=["mediawiki.special.userrights","mediawiki.userSuggest","site","mediawiki.page.ready","skins.vector.legacy.js","mmv.head","mmv.bootstrap.autostart","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader","ext.eventLogging","ext.wikimediaEvents","ext.wikimediaEvents.wikibase","ext.navigationTiming","ext.centralNotice.geoIP","ext.gadget.Slideshow","ext.gadget.ZoomViewer","ext.gadget.CollapsibleTemplates","ext.gadget.fastcci","ext.gadget.Stockphoto","ext.gadget.WatchlistNotice","ext.gadget.AjaxQuickDelete",
"ext.gadget.WikiMiniAtlas","ext.gadget.LanguageSelect","ext.centralauth.centralautologin","ext.uls.compactlinks","ext.uls.interface"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.uls.pt%7Cext.visualEditor.desktopArticleTarget.noscript%7Cext.wikimediaBadges%7Cmediawiki.helplink%2Cspecial%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/w/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="ResourceLoaderDynamicStyles" content=""/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=ext.gadget.Long-Image-Names-in-Categories%2CuploadWizardMobile&amp;only=styles&amp;skin=vector"/>
<link rel="stylesheet" href="/w/load.php?lang=en&amp;modules=site.styles&amp;only=styles&amp;skin=vector"/>
<meta name="generator" content="MediaWiki 1.40.0-wmf.5"/>
<meta name="referrer" content="origin"/>
<meta name="referrer" content="origin-when-crossorigin"/>
<meta name="referrer" content="origin-when-cross-origin"/>
<meta name="robots" content="noindex,nofollow,max-image-preview:standard"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="viewport" content="width=1000"/>
<meta property="og:title" content="User rights - Wikimedia Commons"/>
<meta property="og:type" content="website"/>
<link rel="preconnect" href="//upload.wikimedia.org"/>
<link rel="alternate" media="only screen and (max-width: 720px)" href="//commons.m.wikimedia.org/wiki/Special:UserRights/skins.vector.legacy.js"/>
<link rel="apple-touch-icon" href="/static/apple-touch/commons.png"/>
<link rel="icon" href="/static/favicon/commons.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/w/opensearch_desc.php" title="Wikimedia Commons"/>
<link rel="EditURI" type="application/rsd+xml" href="//commons.wikimedia.org/w/api.php?action=rsd"/>
<link rel="license" href="https://creativecommons.org/licenses/by-sa/3.0/"/>
<link rel="canonical" href="https://commons.wikimedia.org/wiki/Special:UserRights/skins.vector.legacy.js"/>
<link rel="dns-prefetch" href="//login.wikimedia.org"/>
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns--1 ns-special mw-special-Userrights page-Special_UserRights_skins_vector_legacy_js rootpage-Special_UserRights_skins_vector_legacy_js skin-vector action-view skin-vector-legacy vector-toc-not-collapsed vector-feature-language-in-header-disabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-legacy-toc-disabled vector-feature-visual-enhancement-next-disabled vector-feature-article-tools-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"><!-- CentralNotice --></div>
	<div class="mw-indicators">
	<div id="mw-indicator-mw-helplink" class="mw-indicator"><a href="https://www.mediawiki.org/wiki/Special:MyLanguage/Help:Assigning_permissions" target="_blank" class="mw-helplink">Help</a></div>
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading">User rights</h1>
	<div id="bodyContent" class="vector-body">
		
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content"><div class="mw-specialpage-summary">
<table style="box-shadow: 0 0 .2em #999; border-radius: .2em; margin: 0 0 2em 0; padding: 10px; width: 100%; background-color:white;">



<tbody><tr>
<td><div style="float:right;"><a href="/wiki/MediaWiki:Userrights-summary" title="MediaWiki:Userrights-summary">[edit]</a></div>
<ul><li>This page can be used by bureaucrats, administrators and Image reviewers  to add and/or remove users from User groups, see <a href="/wiki/Special:ListGroupRights" title="Special:ListGroupRights">Special:ListGroupRights</a>.</li>
<li>To see recent rights changes, visit <a href="/wiki/Special:Log/rights" title="Special:Log/rights">Special:Log/rights</a>.</li>
<li>Give the user advice about the new rights (see "<i>Some user rights message templates</i>").</li>
<li>Users need to file a <a href="/wiki/Commons:License_review/requests" class="mw-redirect" title="Commons:License review/requests">request</a> to receive the image reviewer flag.<br /></li></ul>
</td></tr></tbody></table>
<hr />
<table class="collapsible collapsed" width="100%">
<tbody><tr>
<th>Some user rights message templates
</th></tr>
<tr>
<td>
<p><a href="/wiki/Commons:Patrol#Autopatrol" title="Commons:Patrol">Autopatrollers</a>: <code>{{subst:Autopatrolgiven}}&#160;~~~~</code><br />
<a href="/wiki/Commons:Patrol" title="Commons:Patrol">Patrollers</a>: <code>{{subst:PatrollerWelcome}}~~~~</code><br />
<a href="/wiki/Commons:File_renaming" title="Commons:File renaming">File movers</a>: <code>{{subst:FilemoverWelcome}}~~~~</code><br />
<a href="/wiki/Commons:Rollback" title="Commons:Rollback">Rollbackers</a>: <code>{{subst:Rollbackgiven}}&#160;~~~~</code><br />
<a href="/wiki/Commons:License_review" title="Commons:License review">Image reviewers</a>: <code>{{subst:Image-reviewerWelcome}}&#160;~~~~</code><br />
<a href="/wiki/Commons:Template_editor" class="mw-redirect" title="Commons:Template editor">Template editors</a>: <code>{{subst:templateeditorgiven}}&#160;~~~~</code><br />
<a href="/wiki/Commons:IP_block_exemption" title="Commons:IP block exemption">IP block exemptions</a>: <code>{{subst:Ipexemptgranted}}&#160;~~~~</code><br />
<a href="/wiki/Commons:Translation_administrators" title="Commons:Translation administrators">Translation administrators</a>: <code>{{subst:TAgiven}}&#160;~~~~</code><br />
<a href="/wiki/Commons:Administrators" title="Commons:Administrators">Administrators</a>: <code>{{subst:AdminWelcome}}&#160;~~~~</code><br />
</p>
<div role="note" style="margin:2px 0; background:#EEE; border:1px solid #DDD; padding:2px;"><img alt="System-search.svg" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/System-search.svg/25px-System-search.svg.png" decoding="async" width="25" height="25" style="vertical-align: middle" srcset="https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/System-search.svg/38px-System-search.svg.png 1.5x, https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/System-search.svg/50px-System-search.svg.png 2x" data-file-width="48" data-file-height="48" />See also&#x3a;&#32;<a href="/wiki/Category:User_rights_message_templates" title="Category:User rights message templates">Category:User rights message templates</a>.&#32;</div>
</td></tr></tbody></table>
<table class="collapsible collapsed" width="100%">
<tbody><tr>
<th>Some tips on making a user an administrator
</th></tr>
<tr>
<td>
<p>Type the name of the user in the box (without the User: namespace prefix) and click "edit user groups". This displays a list of the groups that you can add or remove. Select the groups, and then press "save user groups".
</p><p>See also the <a href="/wiki/Special:Log/rights" title="Special:Log/rights">user rights log</a>.
</p><p>It is suggested that you include a link to the user's request in the comment field. (like this: [[Commons:Administrators/Requests/newlyMintedAdmin]])
</p><p>After you make someone a sysop or bureaucrat, please update the following lists:
</p>
<ul><li><a href="/wiki/Commons:List_of_administrators" title="Commons:List of administrators">Commons:List of administrators</a></li>
<li><a href="/wiki/Commons:List_of_administrators_by_language" title="Commons:List of administrators by language">Commons:List of administrators by language</a></li>
<li><a href="/wiki/Commons:List_of_administrators_by_date" title="Commons:List of administrators by date">Commons:List of administrators by date</a></li></ul>
<p>as well as:
</p>
<ul><li><a href="/wiki/Commons:List_of_administrators_by_adminship_status_in_other_Wikimedia_projects" title="Commons:List of administrators by adminship status in other Wikimedia projects">Commons:List of administrators by adminship status in other Wikimedia projects</a> (this update you may have to ask the candidate to do for you... unless you know for sure what projects they have adminship in)</li></ul>
<p>You can notify the newly created sysop on their talk page, and give them some good advice too, by doing this:
</p><p>{{subst:<a href="/wiki/Template:AdminWelcome" title="Template:AdminWelcome">AdminWelcome</a>}}<br />
"personal remarks" ~~~~
</p><p>(this is probably not necessary for bureaucrats)
</p><p>You should then mark the candidacy ([[Commons:Administrators/Requests/NewlyMintedAdmin]]) as successful by adding a div to gray it out and giving the totals. To do this, add to the top of the RfA:
</p>
<pre>&lt;div style="border:1px #A0A0A0 solid;background-color:#F0F0F0"&gt;

: '' {{support}} = x; {{oppose}} = y; {{neutral}} = z'' - xyz% '''Result'''. &lt;remarks go here&gt; ~~~~

[[Category:Successful requests for adminship]]
</pre>
<p>Save the change, untransclude it from <a href="/wiki/Commons:Administrators/Requests" title="Commons:Administrators/Requests">Commons:Administrators/Requests</a> and add it to <a href="/wiki/Commons:Administrators/Archive" title="Commons:Administrators/Archive">Commons:Administrators/Archive</a> by linking to it at the bottom.
</p>
</td></tr></tbody></table>
<table class="collapsible collapsed" width="100%">
<tbody><tr>
<th>Some tips on making a user a bot
</th></tr>
<tr>
<td>
<p><b>A local bureaucrat can use this page to grant or revoke <a href="/wiki/Commons:Bots" title="Commons:Bots">bot status</a> to another user account.</b><br />
Bot status hides a user's edits from <a href="/wiki/Special:RecentChanges" title="Special:RecentChanges">recent changes</a> and similar lists, and is useful for flagging users who make automated edits. This should be done in accordance with applicable policies which can be seen at <a href="/wiki/Commons:Bots" title="Commons:Bots">Commons:Bots</a>. Please remind the bot operator to update the lists there after you grant the flag...<br />
</p><p>Bots requests are found at <a href="/wiki/Commons:Bots/Requests" title="Commons:Bots/Requests">Commons:Bots/Requests</a>.  Once you grant the request, after a short time, the request should be archived at <a href="/wiki/Commons:Bots/Archive" title="Commons:Bots/Archive">Commons:Bots/Archive</a> in chronological order (newest last). Give a link to the subpage.
</p>
</td></tr></tbody></table>
</div><form method="get" action="/w/index.php" name="uluser" id="mw-userrights-form1"><input type="hidden" value="Special:UserRights" name="title"/><fieldset>
<legend>Select a user</legend>
<label for="username" class="mw-autocomplete-user">Enter a username:</label> <input name="user" size="30" value="skins.vector.legacy.js" id="username" class="mw-autocomplete-user" autofocus="" /> <input type="submit" value="Load user groups"/></fieldset></form>
<p>There is no user by the name "skins.vector.legacy.js".
Check your spelling.
</p><noscript><img src="//commons.wikimedia.org/wiki/Special:CentralAutoLogin/start?type=1x1" alt="" title="" width="1" height="1" style="border: none; position: absolute;" /></noscript>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="https://commons.wikimedia.org/wiki/Special:UserRights/skins.vector.legacy.js">https://commons.wikimedia.org/wiki/Special:UserRights/skins.vector.legacy.js</a>"</div></div>
		<div id="catlinks" class="catlinks catlinks-allhidden" data-mw="interface"></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-uls" class="mw-list-item active"><a class="uls-trigger" href="#"><span>English</span></a></li><li id="pt-anonuserpage" class="mw-list-item"><span title="The user page for the IP address you are editing as">Not logged in</span></li><li id="pt-anontalk" class="mw-list-item"><a href="/wiki/Special:MyTalk" title="Discussion about edits from this IP address [n]" accesskey="n"><span>Talk</span></a></li><li id="pt-anoncontribs" class="mw-list-item"><a href="/wiki/Special:MyContributions" title="A list of edits made from this IP address [y]" accesskey="y"><span>Contributions</span></a></li><li id="pt-createaccount" class="mw-list-item"><a href="/w/index.php?title=Special:CreateAccount&amp;returnto=Special%3AUserRights%2Fskins.vector.legacy.js" title="You are encouraged to create an account and log in; however, it is not mandatory"><span>Create account</span></a></li><li id="pt-login" class="mw-list-item"><a href="/w/index.php?title=Special:UserLogin&amp;returnto=Special%3AUserRights%2Fskins.vector.legacy.js" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-special" class="selected mw-list-item"><a href="/wiki/Special:UserRights/skins.vector.legacy.js" title="This is a special page, and it cannot be edited"><span>Special page</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views emptyPortlet vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown-noicon vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/w/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Wikimedia Commons" aria-label="Search Wikimedia Commons" autocapitalize="sentences" title="Search Wikimedia Commons [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:MediaSearch">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/wiki/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-navigation" class="vector-menu mw-portlet mw-portlet-navigation vector-menu-portal portal" aria-labelledby="p-navigation-label" role="navigation"  >
	<h3
		id="p-navigation-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Navigate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-mainpage-description" class="mw-list-item"><a href="/wiki/Main_Page" title="Visit the main page [z]" accesskey="z"><span>Main page</span></a></li><li id="n-welcome" class="mw-list-item"><a href="/wiki/Commons:Welcome"><span>Welcome</span></a></li><li id="n-portal" class="mw-list-item"><a href="/wiki/Commons:Community_portal" title="About the project, what you can do, where to find things"><span>Community portal</span></a></li><li id="n-village-pump" class="mw-list-item"><a href="/wiki/Commons:Village_pump"><span>Village pump</span></a></li><li id="n-help" class="mw-list-item"><a href="/wiki/Special:MyLanguage/Help:Contents" title="The place to find out"><span>Help center</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-participate" class="vector-menu mw-portlet mw-portlet-participate vector-menu-portal portal" aria-labelledby="p-participate-label" role="navigation"  >
	<h3
		id="p-participate-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Participate</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-uploadbtn" class="mw-list-item"><a href="/wiki/Special:UploadWizard"><span>Upload file</span></a></li><li id="n-recentchanges" class="mw-list-item"><a href="/wiki/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r"><span>Recent changes</span></a></li><li id="n-latestfiles" class="mw-list-item"><a href="/wiki/Special:NewFiles"><span>Latest files</span></a></li><li id="n-randomimage" class="mw-list-item"><a href="/wiki/Special:Random/File" title="Load a random file [x]" accesskey="x"><span>Random file</span></a></li><li id="n-contact" class="mw-list-item"><a href="/wiki/Commons:Contact_us"><span>Contact us</span></a></li></ul>
		
	</div>
</nav>


<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="t-specialpages" class="mw-list-item"><a href="/wiki/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-print" class="mw-list-item"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li></ul>
		
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="https://foundation.wikimedia.org/wiki/Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/wiki/Commons:Welcome">About Wikimedia Commons</a></li>
	<li id="footer-places-disclaimers"><a href="/wiki/Commons:General_disclaimer">Disclaimers</a></li>
	<li id="footer-places-mobileview"><a href="//commons.m.wikimedia.org/w/index.php?title=Special:UserRights/skins.vector.legacy.js&amp;mobileaction=toggle_view_mobile" class="noprint stopMobileRedirectToggle">Mobile view</a></li>
	<li id="footer-places-developers"><a href="https://developer.wikimedia.org">Developers</a></li>
	<li id="footer-places-statslink"><a href="https://stats.wikimedia.org/#/commons.wikimedia.org">Statistics</a></li>
	<li id="footer-places-cookiestatement"><a href="https://foundation.wikimedia.org/wiki/Cookie_statement">Cookie statement</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-copyrightico"><a href="https://wikimediafoundation.org/"><img src="/static/images/footer/wikimedia-button.png" srcset="/static/images/footer/wikimedia-button-1.5x.png 1.5x, /static/images/footer/wikimedia-button-2x.png 2x" width="88" height="31" alt="Wikimedia Foundation" loading="lazy" /></a></li>
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/static/images/footer/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/static/images/footer/poweredby_mediawiki_132x47.png 1.5x, /static/images/footer/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.030","walltime":"0.048","ppvisitednodes":{"value":296,"limit":1000000},"postexpandincludesize":{"value":1159,"limit":2097152},"templateargumentsize":{"value":597,"limit":2097152},"expansiondepth":{"value":8,"limit":100},"expensivefunctioncount":{"value":0,"limit":500},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":619,"limit":5000000},"entityaccesscount":{"value":0,"limit":400},"timingprofile":["100.00%   33.096      1 -total"," 75.44%   24.969      1 Template:Seealso"," 54.73%   18.112      1 Template:Colon"," 51.32%   16.985      2 Template:LangSwitch"," 18.19%    6.019      1 Template:Box-2","  9.99%    3.305      1 Template:Full_stop","  5.51%    1.823      1 Template:Tls","  5.37%    1.777      1 Template:Box-2/Style"]},"scribunto":{"limitreport-timeusage":{"value":"0.004","limit":"10.000"},"limitreport-memusage":{"value":676622,"limit":52428800}},"cachereport":{"origin":"mw2327","timestamp":"20221015185012","ttl":1814400,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":115,"wgHostname":"mw2327"});});</script>
</body>
</html>